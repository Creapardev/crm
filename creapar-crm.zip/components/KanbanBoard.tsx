import React from 'react';
import type { Client, List } from '../types';

interface KanbanBoardProps {
  clients: Client[];
  lists: List[];
  updateClientList: (clientId: string, newListId: string) => void;
}

const KanbanCard: React.FC<{ client: Client }> = ({ client }) => {
  const onDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    e.dataTransfer.setData('clientId', client.id);
    e.currentTarget.classList.add('opacity-50', 'scale-105', 'shadow-lg');
  };

  const onDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
      e.currentTarget.classList.remove('opacity-50', 'scale-105', 'shadow-lg');
  }

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      className="bg-white dark:bg-slate-800 p-3 mb-3 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700 cursor-grab active:cursor-grabbing transition-all duration-150 ease-in-out"
    >
      <div className="flex items-center space-x-3">
        <img src={client.avatarUrl} alt={client.name} className="w-10 h-10 rounded-full" />
        <div>
          <p className="font-semibold text-sm text-slate-800 dark:text-slate-100">{client.name}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">{client.email}</p>
        </div>
      </div>
    </div>
  );
};

export const KanbanBoard: React.FC<KanbanBoardProps> = ({ clients, lists, updateClientList }) => {

    const handleDrop = (e: React.DragEvent<HTMLDivElement>, listId: string) => {
        e.preventDefault();
        const clientId = e.dataTransfer.getData('clientId');
        if (clientId) {
            updateClientList(clientId, listId);
        }
        e.currentTarget.classList.remove('bg-primary-500/10', 'border-primary-500');
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
    }
    
    const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.currentTarget.classList.add('bg-primary-500/10', 'border-primary-500');
    }

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.currentTarget.classList.remove('bg-primary-500/10', 'border-primary-500');
    }

    return (
        <div className="flex space-x-4 h-full overflow-x-auto">
            {lists.map(list => (
                <div
                    key={list.id}
                    className="flex-shrink-0 w-80 h-full flex flex-col"
                >
                    <div className="p-3 sticky top-0 bg-slate-100 dark:bg-slate-900 z-10">
                        <h3 className="font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-between">
                            <span>{list.name}</span>
                            <span className="text-sm font-normal bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-full px-2 py-0.5">
                                {clients.filter(c => c.listId === list.id).length}
                            </span>
                        </h3>
                    </div>
                    <div
                      className="drop-zone flex-1 bg-slate-200/50 dark:bg-slate-800/80 rounded-xl overflow-y-auto p-2 border-2 border-transparent transition-colors duration-200"
                      onDrop={(e) => handleDrop(e, list.id)}
                      onDragOver={handleDragOver}
                      onDragEnter={handleDragEnter}
                      onDragLeave={handleDragLeave}
                    >
                        {clients
                            .filter(c => c.listId === list.id)
                            .map(client => (
                                <KanbanCard key={client.id} client={client} />
                            ))
                        }
                    </div>
                </div>
            ))}
        </div>
    )
}