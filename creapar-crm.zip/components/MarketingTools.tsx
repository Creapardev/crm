import React, { useState, useEffect, useMemo, FC, ReactNode } from 'react';
import type { Client, SWOTAnalysis, ClientQuestionnaire, BCGMatrixAnalysis, BCGMatrixItem, GmbProfile, PersonaAnalysis, Persona } from '../types';
import { MegaphoneIcon, QuestionMarkCircleIcon, SparklesIcon, ViewColumnsIcon, TrashIcon, PlusIcon, StorefrontIcon, IdentificationIcon } from './icons';

interface MarketingToolsProps {
  clients: Client[];
  swotAnalyses: SWOTAnalysis[];
  clientQuestionnaires: ClientQuestionnaire[];
  bcgAnalyses: BCGMatrixAnalysis[];
  gmbProfiles: GmbProfile[];
  personas: PersonaAnalysis[];
  saveSwotAnalysis: (analysis: Omit<SWOTAnalysis, 'id' | 'accountId'> | SWOTAnalysis) => void;
  saveClientQuestionnaire: (questionnaire: ClientQuestionnaire) => void;
  saveBcgAnalysis: (analysis: BCGMatrixAnalysis) => void;
  saveGmbProfile: (profile: GmbProfile) => void;
  savePersonaAnalysis: (analysis: PersonaAnalysis) => void;
  deletePersonaAnalysis: (clientId: string) => void;
  generateQuestionnaire: (clientId: string) => Promise<void>;
  analyzeAndCreateSwot: (questionnaire: ClientQuestionnaire) => Promise<void>;
  estimateBcgMetrics: (productName: string) => Promise<{ marketShare: number; marketGrowth: number } | null>;
  generatePersonas: (clientId: string, businessDescription: string) => Promise<void>;
  optimizeGmbDescription: (category: string, description: string) => Promise<string>;
  generateGmbPostIdeas: (category: string, name: string) => Promise<{ title: string; content: string }[]>;
  suggestGmbServices: (category: string, description: string) => Promise<string[]>;
  generateGmbReviewResponse: (reviewText: string, isPositive: boolean) => Promise<string>;
  isAiAvailable: boolean;
}

const SWOT_TEMPLATE: Omit<SWOTAnalysis, 'id' | 'clientId' | 'accountId'> = {
  strengths: '',
  weaknesses: '',
  opportunities: '',
  threats: '',
};

const BCG_TEMPLATE: Omit<BCGMatrixAnalysis, 'id' | 'clientId' | 'accountId'> = {
    items: [],
};

const GMB_TEMPLATE: Omit<GmbProfile, 'id' | 'clientId' | 'accountId'> = {
    companyName: '',
    category: '',
    description: '',
    optimizedDescription: '',
    postIdeas: [],
    serviceSuggestions: [],
    reviewToAnalyze: '',
    reviewResponse: '',
};

const PERSONA_TEMPLATE: Omit<PersonaAnalysis, 'id' | 'clientId' | 'accountId'> = {
    businessDescription: '',
    personas: [],
};


const SwotCard: React.FC<{
  title: string;
  bgColor: string;
  value: string;
  onChange: (value: string) => void;
}> = ({ title, bgColor, value, onChange }) => (
  <div className={`rounded-xl shadow-sm flex flex-col ${bgColor}`}>
    <h3 className="text-lg font-semibold p-4 border-b border-black/10 text-slate-800 dark:text-white">{title}</h3>
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="flex-1 p-4 bg-transparent resize-none focus:outline-none text-slate-600 dark:text-slate-300 placeholder:text-slate-400 min-h-[150px]"
      placeholder={`Digite as ${title.toLowerCase()}...`}
    />
  </div>
);

const SwotAnalysisTool: React.FC<{
    selectedClientId: string;
    swotAnalyses: SWOTAnalysis[];
    saveSwotAnalysis: (analysis: Omit<SWOTAnalysis, 'id' | 'accountId'> | SWOTAnalysis) => void;
}> = ({ selectedClientId, swotAnalyses, saveSwotAnalysis }) => {
    const [currentSwot, setCurrentSwot] = useState(SWOT_TEMPLATE);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'dirty' | 'saving' | 'saved'>('idle');

    useEffect(() => {
        if (selectedClientId) {
            const existingSwot = swotAnalyses.find(s => s.clientId === selectedClientId);
            setCurrentSwot(existingSwot || SWOT_TEMPLATE);
            setSaveStatus('idle');
        } else {
            setCurrentSwot(SWOT_TEMPLATE);
        }
    }, [selectedClientId]);
    
    useEffect(() => {
        if (saveStatus !== 'dirty') return;

        const handler = setTimeout(() => {
            setSaveStatus('saving');
            const dataToSave = { ...currentSwot, clientId: selectedClientId };
            saveSwotAnalysis(dataToSave);
            setTimeout(() => setSaveStatus('saved'), 500);
        }, 1500);

        return () => clearTimeout(handler);
    }, [saveStatus, currentSwot, selectedClientId, saveSwotAnalysis]);

    const handleSwotChange = (field: keyof typeof SWOT_TEMPLATE, value: string) => {
        setCurrentSwot(prev => ({ ...prev, [field]: value }));
        setSaveStatus('dirty');
    };

    const getSaveStatusMessage = () => {
        switch (saveStatus) {
            case 'dirty': return 'Digitando...';
            case 'saving': return 'Salvando...';
            case 'saved': return 'Salvo!';
            default: return 'Pronto.';
        }
    };
    
    return (
        <>
            <div className="flex justify-end">
                 <div className="text-sm text-slate-500 dark:text-slate-400 min-w-[100px] text-right">
                    {getSaveStatusMessage()}
                 </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-1">
                <SwotCard title="Forças (Strengths)" bgColor="bg-green-50 dark:bg-green-500/10" value={currentSwot.strengths} onChange={(val) => handleSwotChange('strengths', val)}/>
                <SwotCard title="Fraquezas (Weaknesses)" bgColor="bg-red-50 dark:bg-red-500/10" value={currentSwot.weaknesses} onChange={(val) => handleSwotChange('weaknesses', val)}/>
                <SwotCard title="Oportunidades (Opportunities)" bgColor="bg-blue-50 dark:bg-blue-500/10" value={currentSwot.opportunities} onChange={(val) => handleSwotChange('opportunities', val)}/>
                <SwotCard title="Ameaças (Threats)" bgColor="bg-amber-50 dark:bg-amber-500/10" value={currentSwot.threats} onChange={(val) => handleSwotChange('threats', val)}/>
            </div>
        </>
    );
}

const QuestionnaireTool: React.FC<{
    selectedClientId: string;
    clientQuestionnaires: ClientQuestionnaire[];
    saveClientQuestionnaire: (questionnaire: ClientQuestionnaire) => void;
    generateQuestionnaire: (clientId: string) => Promise<void>;
    analyzeAndCreateSwot: (questionnaire: ClientQuestionnaire) => Promise<void>;
    switchToSwot: () => void;
}> = ({ selectedClientId, clientQuestionnaires, saveClientQuestionnaire, generateQuestionnaire, analyzeAndCreateSwot, switchToSwot }) => {
    
    const [isLoading, setIsLoading] = useState(false);
    const [currentQuestionnaire, setCurrentQuestionnaire] = useState<ClientQuestionnaire | null>(null);

    useEffect(() => {
        const existing = clientQuestionnaires.find(q => q.clientId === selectedClientId);
        setCurrentQuestionnaire(existing || null);
    }, [selectedClientId]);

    const handleGenerate = async () => {
        setIsLoading(true);
        try {
            await generateQuestionnaire(selectedClientId);
        } catch(error) {
            console.error("Failed to generate questionnaire", error);
            alert("Falha ao gerar questionário. Verifique o console para mais detalhes.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleAnalyze = async () => {
        if (!currentQuestionnaire) return;
        setIsLoading(true);
        try {
            await analyzeAndCreateSwot(currentQuestionnaire);
            alert("Análise SWOT criada com sucesso! Verifique a aba de Análise SWOT.");
            switchToSwot();
        } catch(error) {
            console.error("Failed to analyze and create SWOT", error);
            alert("Falha ao analisar o questionário. Verifique o console para mais detalhes.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleAnswerChange = (index: number, answer: string) => {
        if (!currentQuestionnaire) return;
        const newQuestions = [...currentQuestionnaire.questions];
        newQuestions[index] = { ...newQuestions[index], answer };
        const updatedQuestionnaire = { ...currentQuestionnaire, questions: newQuestions };
        setCurrentQuestionnaire(updatedQuestionnaire);
        // Debounced save
        const handler = setTimeout(() => saveClientQuestionnaire(updatedQuestionnaire), 1000);
        return () => clearTimeout(handler);
    }
    
    const isQuestionnaireFilled = useMemo(() => {
        return currentQuestionnaire?.questions.every(q => q.answer.trim() !== '');
    }, [currentQuestionnaire]);

    if (isLoading) {
        return (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-4">
                <SparklesIcon className="w-16 h-16 text-primary-500 mb-4 animate-pulse" />
                <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">A IA está trabalhando...</h3>
                <p className="text-slate-500 dark:text-slate-400 mt-2">Isso pode levar alguns segundos.</p>
            </div>
        );
    }

    return (
        <div className="flex-1 flex flex-col gap-4">
            {!currentQuestionnaire ? (
                <div className="text-center">
                    <button onClick={handleGenerate} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-lg shadow-sm hover:bg-primary-700">
                        <SparklesIcon className="w-5 h-5" />
                        Gerar Questionário com IA
                    </button>
                </div>
            ) : (
                <div className="space-y-6">
                    {currentQuestionnaire.questions.map((item, index) => (
                        <div key={index}>
                            <label className="block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-2">{index + 1}. {item.question}</label>
                            <textarea
                                value={item.answer}
                                onChange={(e) => handleAnswerChange(index, e.target.value)}
                                rows={3}
                                className="w-full rounded-lg border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                                placeholder="Sua resposta..."
                            />
                        </div>
                    ))}
                    <div className="flex justify-end">
                        <button 
                            onClick={handleAnalyze} 
                            disabled={!isQuestionnaireFilled}
                            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg shadow-sm hover:bg-green-700 disabled:bg-slate-400 disabled:cursor-not-allowed"
                        >
                            <SparklesIcon className="w-5 h-5" />
                            Analisar e Criar SWOT com IA
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

const BcgMatrixTool: React.FC<{
    selectedClientId: string;
    bcgAnalyses: BCGMatrixAnalysis[];
    saveBcgAnalysis: (analysis: BCGMatrixAnalysis) => void;
    estimateBcgMetrics: (productName: string) => Promise<{ marketShare: number; marketGrowth: number } | null>;
}> = ({ selectedClientId, bcgAnalyses, saveBcgAnalysis, estimateBcgMetrics }) => {
    const [currentBcg, setCurrentBcg] = useState<BCGMatrixAnalysis>(BCG_TEMPLATE as BCGMatrixAnalysis);
    const [newItemName, setNewItemName] = useState('');
    const [isEstimating, setIsEstimating] = useState<string | null>(null); // holds item id

    useEffect(() => {
        if (selectedClientId) {
            const existingBcg = bcgAnalyses.find(b => b.clientId === selectedClientId);
            setCurrentBcg(existingBcg || { ...BCG_TEMPLATE, id: `bcg-${selectedClientId}`, clientId: selectedClientId, accountId: '' });
        } else {
            setCurrentBcg({ ...BCG_TEMPLATE, id: '', clientId: '', accountId: '' });
        }
    }, [selectedClientId]);

    useEffect(() => {
        if (!currentBcg.clientId) return; // Don't save if no client is selected
        const handler = setTimeout(() => {
            saveBcgAnalysis(currentBcg);
        }, 1000);
        return () => clearTimeout(handler);
    }, [currentBcg, saveBcgAnalysis]);


    const handleUpdateItem = (itemId: string, field: 'marketShare' | 'marketGrowth', value: number) => {
        setCurrentBcg(prev => ({
            ...prev,
            items: prev.items.map(it => it.id === itemId ? { ...it, [field]: value } : it),
        }));
    };

    const handleAddItem = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newItemName.trim()) return;
        const newItem: BCGMatrixItem = {
            id: `item-${Date.now()}`,
            name: newItemName.trim(),
            marketShare: 50,
            marketGrowth: 50,
        };
        setCurrentBcg(prev => ({ ...prev, items: [...prev.items, newItem] }));
        setNewItemName('');
    };
    
    const handleDeleteItem = (itemId: string) => {
        setCurrentBcg(prev => ({ ...prev, items: prev.items.filter(it => it.id !== itemId) }));
    };
    
    const handleEstimate = async (item: BCGMatrixItem) => {
        setIsEstimating(item.id);
        const result = await estimateBcgMetrics(item.name);
        if (result) {
            setCurrentBcg(prev => ({
                ...prev,
                items: prev.items.map(it => it.id === item.id ? { ...it, ...result } : it),
            }));
        } else {
            alert("Não foi possível estimar as métricas para este item.");
        }
        setIsEstimating(null);
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-4">
                <form onSubmit={handleAddItem} className="flex gap-2 p-4 border rounded-lg dark:border-slate-700">
                    <input type="text" value={newItemName} onChange={e => setNewItemName(e.target.value)} placeholder="Nome do Produto/Serviço" className="flex-grow block w-full rounded-md border-slate-300 shadow-sm sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white" required/>
                    <button type="submit" className="p-2 text-white bg-primary-600 rounded-md hover:bg-primary-700"><PlusIcon className="w-5 h-5" /></button>
                </form>
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                    {currentBcg.items.map(item => (
                        <div key={item.id} className="p-3 bg-slate-100 dark:bg-slate-700/50 rounded-lg">
                            <div className="flex justify-between items-center mb-2">
                                <p className="font-semibold text-sm text-slate-800 dark:text-slate-200">{item.name}</p>
                                <div className="flex items-center gap-1">
                                    <button onClick={() => handleEstimate(item)} disabled={!!isEstimating} className="p-1 text-primary-500 disabled:text-slate-400 disabled:cursor-wait">
                                       <SparklesIcon className={`w-4 h-4 ${isEstimating === item.id ? 'animate-pulse' : ''}`}/>
                                    </button>
                                    <button onClick={() => handleDeleteItem(item.id)} className="p-1 text-red-500"><TrashIcon className="w-4 h-4" /></button>
                                </div>
                            </div>
                            <div className="space-y-2 text-xs">
                                <div>
                                    <label>Participação de Mercado ({item.marketShare})</label>
                                    <input type="range" min="0" max="100" value={item.marketShare} onChange={e => handleUpdateItem(item.id, 'marketShare', +e.target.value)} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-600"/>
                                </div>
                                <div>
                                    <label>Crescimento de Mercado ({item.marketGrowth})</label>
                                    <input type="range" min="0" max="100" value={item.marketGrowth} onChange={e => handleUpdateItem(item.id, 'marketGrowth', +e.target.value)} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-600"/>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <div className="lg:col-span-2 relative">
                <div className="absolute top-0 left-0 w-full h-full p-4 flex flex-col pointer-events-none">
                    <div className="flex-1 flex justify-between">
                        <span className="text-xs font-bold text-slate-400 -rotate-90 origin-bottom-left">Crescimento de Mercado</span>
                    </div>
                     <span className="text-xs font-bold text-slate-400">Participação de Mercado</span>
                </div>
                <div className="relative w-full aspect-square bg-slate-100 dark:bg-slate-900/30 rounded-xl grid grid-cols-2 grid-rows-2 gap-px border border-slate-300 dark:border-slate-700">
                     {/* Quadrant Labels */}
                     <div className="absolute top-2 left-2 text-amber-500 font-bold text-sm">?</div>
                     <div className="absolute top-2 right-2 text-blue-500 font-bold text-sm">★</div>
                     <div className="absolute bottom-2 left-2 text-red-500 font-bold text-sm">🐶</div>
                     <div className="absolute bottom-2 right-2 text-green-500 font-bold text-sm">$</div>

                    {currentBcg.items.map((item, index) => (
                        <div key={item.id} title={item.name} className="absolute transition-all duration-300" style={{ right: `${item.marketShare}%`, bottom: `${item.marketGrowth}%` }}>
                            <div className="w-4 h-4 rounded-full bg-primary-500 border-2 border-white dark:border-slate-800 transform -translate-x-1/2 translate-y-1/2 flex items-center justify-center cursor-pointer group">
                                <span className="absolute bottom-full mb-2 w-max bg-slate-800 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                    {item.name}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const GmbOptimizerTool: React.FC<{
  selectedClientId: string;
  gmbProfiles: GmbProfile[];
  saveGmbProfile: (profile: GmbProfile) => void;
  optimizeGmbDescription: (category: string, description: string) => Promise<string>;
  generateGmbPostIdeas: (category: string, name: string) => Promise<{ title: string; content: string }[]>;
  suggestGmbServices: (category: string, description: string) => Promise<string[]>;
  generateGmbReviewResponse: (reviewText: string, isPositive: boolean) => Promise<string>;
}> = (props) => {
    const { selectedClientId, gmbProfiles, saveGmbProfile } = props;
    const [profile, setProfile] = useState<GmbProfile>(GMB_TEMPLATE as GmbProfile);
    const [loadingStates, setLoadingStates] = useState<Record<string, boolean>>({});

    useEffect(() => {
        const existingProfile = gmbProfiles.find(p => p.clientId === selectedClientId);
        setProfile(existingProfile || { ...GMB_TEMPLATE, clientId: selectedClientId } as GmbProfile);
    }, [selectedClientId]);

    useEffect(() => {
        if (!profile.clientId) return;
        const handler = setTimeout(() => saveGmbProfile(profile), 1000);
        return () => clearTimeout(handler);
    }, [profile, saveGmbProfile]);

    const handleUpdate = (field: keyof GmbProfile, value: any) => {
        setProfile(prev => ({ ...prev, [field]: value }));
    };
    
    const runAiAction = async (action: string, aiFunction: () => Promise<any>, updateField: keyof GmbProfile) => {
        setLoadingStates(prev => ({...prev, [action]: true}));
        try {
            const result = await aiFunction();
            handleUpdate(updateField, result);
        } catch (error) {
            console.error(`Error during ${action}:`, error);
            alert(`Falha ao executar a ação de IA: ${action}`);
        } finally {
            setLoadingStates(prev => ({...prev, [action]: false}));
        }
    }
    
    const baseInputClasses = "block w-full rounded-lg border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white";
    const baseTextAreaClasses = `${baseInputClasses} resize-none`;

    return (
        <div className="space-y-8">
            {/* Inputs */}
            <div className="p-4 border rounded-xl dark:border-slate-700 space-y-4">
                <h3 className="font-semibold text-lg text-slate-800 dark:text-slate-200">Informações do Perfil</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="text-sm font-medium">Nome da Empresa</label>
                        <input type="text" value={profile.companyName} onChange={e => handleUpdate('companyName', e.target.value)} className={baseInputClasses}/>
                    </div>
                    <div>
                        <label className="text-sm font-medium">Categoria</label>
                        <input type="text" value={profile.category} onChange={e => handleUpdate('category', e.target.value)} placeholder="Ex: Restaurante Italiano" className={baseInputClasses}/>
                    </div>
                </div>
                <div>
                    <label className="text-sm font-medium">Descrição Atual</label>
                    <textarea value={profile.description} onChange={e => handleUpdate('description', e.target.value)} rows={4} className={baseTextAreaClasses}></textarea>
                </div>
            </div>

            {/* AI Modules */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Description Optimizer */}
                <div className="space-y-3">
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Descrição Otimizada</h4>
                    <button onClick={() => runAiAction('description', () => props.optimizeGmbDescription(profile.category, profile.description), 'optimizedDescription')} disabled={loadingStates.description} className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 disabled:bg-slate-400">
                        <SparklesIcon className="w-4 h-4" /> {loadingStates.description ? 'Otimizando...' : 'Otimizar com IA'}
                    </button>
                    <textarea value={profile.optimizedDescription} readOnly rows={5} placeholder="A descrição otimizada pela IA aparecerá aqui..." className={`${baseTextAreaClasses} bg-slate-50 dark:bg-slate-900/50`}></textarea>
                </div>

                {/* Post Ideas */}
                <div className="space-y-3">
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Ideias de Posts</h4>
                    <button onClick={() => runAiAction('posts', () => props.generateGmbPostIdeas(profile.category, profile.companyName), 'postIdeas')} disabled={loadingStates.posts} className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 disabled:bg-slate-400">
                         <SparklesIcon className="w-4 h-4" /> {loadingStates.posts ? 'Gerando...' : 'Gerar Ideias com IA'}
                    </button>
                    <div className="space-y-2 max-h-48 overflow-y-auto p-2 border rounded-lg dark:border-slate-700">
                        {profile.postIdeas.length > 0 ? profile.postIdeas.map((post, i) => (
                            <div key={i} className="p-2 bg-slate-50 dark:bg-slate-700/50 rounded-md text-sm">
                                <p className="font-bold text-slate-700 dark:text-slate-200">{post.title}</p>
                                <p className="text-slate-600 dark:text-slate-300">{post.content}</p>
                            </div>
                        )) : <p className="text-slate-400 text-sm p-2">As ideias de posts aparecerão aqui...</p>}
                    </div>
                </div>

                {/* Service Suggestions */}
                 <div className="space-y-3">
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Sugestão de Serviços</h4>
                    <button onClick={() => runAiAction('services', () => props.suggestGmbServices(profile.category, profile.description), 'serviceSuggestions')} disabled={loadingStates.services} className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 disabled:bg-slate-400">
                         <SparklesIcon className="w-4 h-4" /> {loadingStates.services ? 'Sugerindo...' : 'Sugerir com IA'}
                    </button>
                     <div className="space-y-2 max-h-48 overflow-y-auto p-2 border rounded-lg dark:border-slate-700">
                        {profile.serviceSuggestions.length > 0 ? (
                            <ul className="list-disc list-inside text-sm text-slate-600 dark:text-slate-300">
                                {profile.serviceSuggestions.map((service, i) => <li key={i}>{service}</li>)}
                            </ul>
                        ) : <p className="text-slate-400 text-sm p-2">As sugestões de serviços aparecerão aqui...</p>}
                    </div>
                </div>

                {/* Review Responder */}
                <div className="space-y-3">
                    <h4 className="font-semibold text-slate-800 dark:text-slate-200">Assistente de Resposta a Avaliações</h4>
                    <textarea value={profile.reviewToAnalyze} onChange={e => handleUpdate('reviewToAnalyze', e.target.value)} rows={3} placeholder="Cole a avaliação do cliente aqui..." className={baseTextAreaClasses}></textarea>
                    <div className="flex gap-2">
                        <button onClick={() => runAiAction('review_pos', () => props.generateGmbReviewResponse(profile.reviewToAnalyze, true), 'reviewResponse')} disabled={!profile.reviewToAnalyze || loadingStates.review_pos || loadingStates.review_neg} className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-white bg-green-600 rounded-md hover:bg-green-700 disabled:bg-slate-400">
                            {loadingStates.review_pos ? 'Gerando...' : 'Resposta Positiva'}
                        </button>
                        <button onClick={() => runAiAction('review_neg', () => props.generateGmbReviewResponse(profile.reviewToAnalyze, false), 'reviewResponse')} disabled={!profile.reviewToAnalyze || loadingStates.review_pos || loadingStates.review_neg} className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 disabled:bg-slate-400">
                             {loadingStates.review_neg ? 'Gerando...' : 'Resposta Negativa'}
                        </button>
                    </div>
                    <textarea value={profile.reviewResponse} readOnly rows={4} placeholder="A resposta da IA aparecerá aqui..." className={`${baseTextAreaClasses} bg-slate-50 dark:bg-slate-900/50`}></textarea>
                </div>
            </div>
        </div>
    );
}

const PersonaCard: React.FC<{ persona: Persona }> = ({ persona }) => (
    <div className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-5 flex flex-col gap-4">
        <div className="flex items-center gap-4">
            <img src={persona.avatarUrl} alt={persona.name} className="w-16 h-16 rounded-full" />
            <div>
                <h4 className="font-bold text-lg text-primary-600 dark:text-primary-400">{persona.name}</h4>
                <p className="text-sm text-slate-600 dark:text-slate-300">{persona.jobTitle} - {persona.age} anos</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{persona.location}</p>
            </div>
        </div>
        <p className="text-sm italic text-slate-500 dark:text-slate-400 border-l-4 border-slate-300 dark:border-slate-600 pl-4">"{persona.quote}"</p>
        <p className="text-sm text-slate-700 dark:text-slate-300">{persona.bio}</p>
        <div>
            <h5 className="font-semibold text-sm mb-1 text-slate-800 dark:text-slate-200">Metas</h5>
            <ul className="list-disc list-inside text-sm space-y-1 text-slate-600 dark:text-slate-300">
                {persona.goals.map((goal, i) => <li key={i}>{goal}</li>)}
            </ul>
        </div>
        <div>
            <h5 className="font-semibold text-sm mb-1 text-slate-800 dark:text-slate-200">Dores</h5>
            <ul className="list-disc list-inside text-sm space-y-1 text-slate-600 dark:text-slate-300">
                {persona.painPoints.map((pain, i) => <li key={i}>{pain}</li>)}
            </ul>
        </div>
    </div>
);

const PersonaGeneratorTool: React.FC<{
    selectedClientId: string;
    personas: PersonaAnalysis[];
    savePersonaAnalysis: (analysis: PersonaAnalysis) => void;
    deletePersonaAnalysis: (clientId: string) => void;
    generatePersonas: (clientId: string, businessDescription: string) => Promise<void>;
}> = ({ selectedClientId, personas, savePersonaAnalysis, deletePersonaAnalysis, generatePersonas }) => {
    
    const [analysis, setAnalysis] = useState<PersonaAnalysis>(PERSONA_TEMPLATE as PersonaAnalysis);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const existing = personas.find(p => p.clientId === selectedClientId);
        setAnalysis(existing || { ...PERSONA_TEMPLATE, clientId: selectedClientId } as PersonaAnalysis);
    }, [selectedClientId]);
    
    const handleGenerate = async () => {
        if (!analysis.businessDescription.trim()) {
            alert("Por favor, forneça uma descrição do negócio.");
            return;
        }
        setIsLoading(true);
        try {
            await generatePersonas(selectedClientId, analysis.businessDescription);
        } catch(e) {
            console.error(e);
            alert("Falha ao gerar personas. Verifique o console.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleDescriptionChange = (desc: string) => {
        const newAnalysis = {...analysis, businessDescription: desc};
        setAnalysis(newAnalysis);
        // Debounced save
        const handler = setTimeout(() => savePersonaAnalysis(newAnalysis), 1000);
        return () => clearTimeout(handler);
    }

    return (
        <div className="space-y-6">
            <div>
                <label className="block text-sm font-semibold text-slate-800 dark:text-slate-200 mb-2">
                    Descrição do Negócio e Público-Alvo
                </label>
                <textarea
                    value={analysis.businessDescription}
                    onChange={e => handleDescriptionChange(e.target.value)}
                    rows={3}
                    className="w-full rounded-lg border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
                    placeholder="Ex: Uma cafeteria gourmet que vende cafés especiais para jovens profissionais e estudantes universitários."
                />
            </div>
             <div className="flex items-center gap-4">
                <button onClick={handleGenerate} disabled={isLoading} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-lg shadow-sm hover:bg-primary-700 disabled:bg-slate-400">
                    <SparklesIcon className={`w-5 h-5 ${isLoading ? 'animate-pulse' : ''}`} />
                    {isLoading ? 'Gerando...' : 'Gerar Personas com IA'}
                </button>
                {analysis.personas.length > 0 && (
                     <button onClick={() => deletePersonaAnalysis(selectedClientId)} className="text-sm text-red-600 hover:underline">
                        Limpar Personas
                    </button>
                )}
            </div>

            {isLoading ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[...Array(3)].map((_, i) => (
                        <div key={i} className="bg-slate-100 dark:bg-slate-700/50 rounded-xl p-5 animate-pulse min-h-[400px]"></div>
                    ))}
                 </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {analysis.personas.map((persona, index) => (
                        <PersonaCard key={index} persona={persona} />
                    ))}
                </div>
            )}
        </div>
    );
}

export const MarketingTools: React.FC<MarketingToolsProps> = (props) => {
  const [selectedClientId, setSelectedClientId] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'questionnaire' | 'swot' | 'bcg' | 'gmb' | 'personas'>('questionnaire');
  
  const { clients, isAiAvailable } = props;

  const handleClientChange = (clientId: string) => {
    setSelectedClientId(clientId);
    setActiveTab('questionnaire');
  };

  const TabButton: FC<{ isActive: boolean; onClick: () => void; children: ReactNode; icon: ReactNode }> = ({ isActive, onClick, children, icon }) => (
    <button
        onClick={onClick}
        className={`flex items-center gap-2 whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors ${
            isActive
                ? 'border-primary-500 text-primary-600 dark:text-primary-400'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300 dark:text-slate-400 dark:hover:text-slate-200 dark:hover:border-slate-600'
        }`}
    >
        {icon}
        {children}
    </button>
  );

  const tabs = [
    { id: 'personas', label: 'Gerador de Personas', icon: <IdentificationIcon className="w-5 h-5" /> },
    { id: 'questionnaire', label: 'Questionário SWOT', icon: <QuestionMarkCircleIcon className="w-5 h-5" /> },
    { id: 'swot', label: 'Análise SWOT', icon: <MegaphoneIcon className="w-5 h-5" /> },
    { id: 'bcg', label: 'Matriz BCG', icon: <ViewColumnsIcon className="w-5 h-5" /> },
    { id: 'gmb', label: 'Otimizador GMB', icon: <StorefrontIcon className="w-5 h-5" /> },
  ];

  const renderContent = () => {
    if (!selectedClientId) {
      return (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-4 border-2 border-dashed rounded-xl dark:border-slate-700">
              <MegaphoneIcon className="w-16 h-16 text-slate-400 dark:text-slate-500 mb-4"/>
              <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Comece sua Análise</h3>
              <p className="text-slate-500 dark:text-slate-400 mt-2">Selecione um cliente no menu acima para usar as ferramentas.</p>
          </div>
      );
    }

    if (!isAiAvailable) {
         return (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-4 border-2 border-dashed rounded-xl border-amber-500/50 dark:border-amber-400/30 bg-amber-50 dark:bg-amber-500/10">
                <SparklesIcon className="w-16 h-16 text-amber-500 dark:text-amber-400 mb-4"/>
                <h3 className="text-xl font-semibold text-amber-800 dark:text-amber-200">Funcionalidade de IA Indisponível</h3>
                <p className="text-amber-600 dark:text-amber-300 mt-2">A chave de API do Gemini não foi configurada. Esta funcionalidade está desativada.</p>
            </div>
        );
    }
    
    switch(activeTab) {
        case 'personas':
            return <PersonaGeneratorTool 
                        selectedClientId={selectedClientId}
                        personas={props.personas}
                        savePersonaAnalysis={props.savePersonaAnalysis}
                        deletePersonaAnalysis={props.deletePersonaAnalysis}
                        generatePersonas={props.generatePersonas}
                    />;
        case 'questionnaire':
            return <QuestionnaireTool 
                        selectedClientId={selectedClientId} 
                        clientQuestionnaires={props.clientQuestionnaires}
                        saveClientQuestionnaire={props.saveClientQuestionnaire}
                        generateQuestionnaire={props.generateQuestionnaire}
                        analyzeAndCreateSwot={props.analyzeAndCreateSwot}
                        switchToSwot={() => setActiveTab('swot')}
                    />;
        case 'swot':
            return <SwotAnalysisTool 
                        swotAnalyses={props.swotAnalyses}
                        saveSwotAnalysis={props.saveSwotAnalysis}
                        selectedClientId={selectedClientId} 
                    />;
        case 'bcg':
            return <BcgMatrixTool 
                        bcgAnalyses={props.bcgAnalyses}
                        saveBcgAnalysis={props.saveBcgAnalysis}
                        estimateBcgMetrics={props.estimateBcgMetrics}
                        selectedClientId={selectedClientId}
                    />;
        case 'gmb':
            return <GmbOptimizerTool
                        selectedClientId={selectedClientId}
                        gmbProfiles={props.gmbProfiles}
                        saveGmbProfile={props.saveGmbProfile}
                        optimizeGmbDescription={props.optimizeGmbDescription}
                        generateGmbPostIdeas={props.generateGmbPostIdeas}
                        suggestGmbServices={props.suggestGmbServices}
                        generateGmbReviewResponse={props.generateGmbReviewResponse}
                    />;
        default:
          return null;
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full flex flex-col">
      <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Ferramentas de Marketing</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Use ferramentas com IA para analisar e otimizar estratégias para seus clientes.</p>
        </div>
        <div>
          <label htmlFor="client-select-marketing" className="sr-only">Selecionar Cliente</label>
          <select 
              id="client-select-marketing"
              value={selectedClientId}
              onChange={(e) => handleClientChange(e.target.value)}
              className="w-full md:w-64 rounded-lg border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"
          >
              <option value="">Selecione um cliente...</option>
              {clients.map(client => (
                  <option key={client.id} value={client.id}>{client.name}</option>
              ))}
          </select>
        </div>
      </div>
      
      {selectedClientId && (
        <div className="border-b border-slate-200 dark:border-slate-700 mb-6">
          <nav className="-mb-px flex space-x-2 md:space-x-6 overflow-x-auto" aria-label="Tabs">
            {tabs.map(tab => (
              <TabButton 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                isActive={activeTab === tab.id}
                icon={tab.icon}
              >
                {tab.label}
              </TabButton>
            ))}
          </nav>
        </div>
      )}

      <div className="flex-1 flex flex-col overflow-y-auto">
        {renderContent()}
      </div>
    </div>
  );
};