import React, { useState, useMemo } from 'react';
import type { Task, Client } from '../types';
import { CheckCircleIcon, PlusIcon, TrashIcon } from './icons';
import { Modal } from './Modal';

interface TaskManagerProps {
  tasks: Task[];
  clients: Client[];
  updateTask: (task: Task) => void;
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'accountId' | 'isCompleted'>) => void;
  deleteTask: (taskId: string) => void;
}

const TaskForm: React.FC<{
  clients: Client[];
  onSave: (taskData: Omit<Task, 'id' | 'createdAt' | 'accountId' | 'isCompleted'>) => void;
  onClose: () => void;
}> = ({ clients, onSave, onClose }) => {
    const [title, setTitle] = useState('');
    const [clientId, setClientId] = useState<string | null>(null);
    const [dueDate, setDueDate] = useState<string | null>(null);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim()) {
            alert("O título da tarefa é obrigatório.");
            return;
        }
        onSave({ title, clientId, dueDate });
        onClose();
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Título da Tarefa</label>
                <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white" />
            </div>
            <div>
                <label htmlFor="clientId" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Cliente (Opcional)</label>
                <select id="clientId" value={clientId || ''} onChange={e => setClientId(e.target.value || null)} className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
                    <option value="">Nenhum</option>
                    {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="dueDate" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Data de Vencimento (Opcional)</label>
                <input type="date" id="dueDate" value={dueDate || ''} onChange={e => setDueDate(e.target.value || null)} className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white" />
            </div>
            <div className="flex justify-end space-x-2 pt-4">
                <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 focus:outline-none dark:bg-slate-600 dark:text-slate-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancelar</button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Salvar Tarefa</button>
            </div>
        </form>
    );
};

export const TaskManager: React.FC<TaskManagerProps> = ({ tasks, clients, updateTask, addTask, deleteTask }) => {
  const [showCompleted, setShowCompleted] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const clientMap = useMemo(() => new Map(clients.map(c => [c.id, c])), [clients]);

  const filteredTasks = useMemo(() => {
    return tasks
        .filter(task => showCompleted ? task.isCompleted : !task.isCompleted)
        .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }, [tasks, showCompleted]);

  const toggleTaskCompletion = (task: Task) => {
    updateTask({ ...task, isCompleted: !task.isCompleted });
  };
  
  const isOverdue = (dueDate: string | null) => {
      if (!dueDate) return false;
      return new Date(dueDate) < new Date() && new Date(dueDate).toDateString() !== new Date().toDateString();
  }

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full flex flex-col">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciamento de Tarefas</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Visualize e gerencie suas tarefas pendentes e concluídas.</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
                onClick={() => setIsModalOpen(true)}
                className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-lg shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
                <PlusIcon className="w-5 h-5"/>
                Adicionar Tarefa
            </button>
            <button
                onClick={() => setShowCompleted(false)}
                className={`px-4 py-2 text-sm font-medium rounded-lg ${!showCompleted ? 'bg-primary-600/20 text-primary-700 dark:text-primary-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'}`}
            >
                Pendentes
            </button>
            <button
                onClick={() => setShowCompleted(true)}
                className={`px-4 py-2 text-sm font-medium rounded-lg ${showCompleted ? 'bg-primary-600/20 text-primary-700 dark:text-primary-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'}`}
            >
                Concluídas
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto flex-1">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700/50">
              <tr>
                <th scope="col" className="w-12 px-6 py-3"></th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Título</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Cliente Associado</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Vencimento</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {filteredTasks.map(task => {
                const client = task.clientId ? clientMap.get(task.clientId) : null;
                const overdue = !task.isCompleted && isOverdue(task.dueDate);
                return (
                  <tr key={task.id} className={`hover:bg-slate-50 dark:hover:bg-slate-700/50 ${task.isCompleted ? 'opacity-60' : ''}`}>
                    <td className="px-6 py-4">
                        <button onClick={() => toggleTaskCompletion(task)} className="flex items-center">
                           <CheckCircleIcon className={`w-6 h-6 transition-colors ${task.isCompleted ? 'text-green-500' : 'text-slate-300 dark:text-slate-600 hover:text-green-400'}`} />
                        </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{task.title}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">
                        {client ? (
                            <div className="flex items-center gap-2">
                                <img src={client.avatarUrl} alt={client.name} className="w-6 h-6 rounded-full"/>
                                <span>{client.name}</span>
                            </div>
                        ) : 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={overdue ? 'text-red-500 font-semibold' : 'text-slate-500 dark:text-slate-300'}>
                          {task.dueDate ? new Date(task.dueDate).toLocaleDateString('pt-BR', {timeZone: 'UTC'}) : 'Sem prazo'}
                        </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                       <button onClick={() => deleteTask(task.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                         <TrashIcon className="w-5 h-5"/>
                       </button>
                    </td>
                  </tr>
                )}
              )}
            </tbody>
          </table>
          {filteredTasks.length === 0 && (
            <div className="text-center py-10">
                <p className="text-slate-500 dark:text-slate-400">Nenhuma tarefa aqui.</p>
            </div>
          )}
        </div>
        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Adicionar Nova Tarefa">
            <TaskForm clients={clients} onSave={addTask} onClose={() => setIsModalOpen(false)} />
        </Modal>
    </div>
  );
};