import React, { useState } from 'react';
import type { Form } from '../types';

interface PublicFormProps {
    form: Form;
}

export const PublicForm: React.FC<PublicFormProps> = ({ form }) => {
    const [formData, setFormData] = useState<Record<string, string>>({});
    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const submission = {
            formId: form.id,
            formData,
            submittedAt: new Date().toISOString(),
        };
        
        try {
            const existingSubmissions = JSON.parse(localStorage.getItem('creapar_form_submissions') || '[]');
            existingSubmissions.push(submission);
            localStorage.setItem('creapar_form_submissions', JSON.stringify(existingSubmissions));
            setSubmitted(true);
        } catch (error) {
            console.error("Failed to save form submission:", error);
            alert("Ocorreu um erro ao enviar o formulário.");
        }
    };
    
    const fontSizeClasses = {
        sm: 'text-sm',
        md: 'text-base',
        lg: 'text-lg',
    };

    if (submitted) {
        return (
            <div
                className="flex items-center justify-center min-h-screen p-4"
                style={{ backgroundColor: form.backgroundColor, color: form.textColor }}
            >
                <div className="text-center">
                    <h1 className={`font-bold ${fontSizeClasses[form.fontSize] === 'text-sm' ? 'text-2xl' : 'text-3xl'}`}>Obrigado!</h1>
                    <p className={`mt-2 ${fontSizeClasses[form.fontSize]}`}>Seu formulário foi enviado com sucesso.</p>
                </div>
            </div>
        );
    }
    
    return (
        <div 
          className="min-h-screen p-4 sm:p-6"
          style={{ backgroundColor: form.backgroundColor, color: form.textColor }}
        >
            <div className={`max-w-xl mx-auto ${fontSizeClasses[form.fontSize]}`}>
                <div className="text-center mb-6">
                    <h1 className={`font-bold ${fontSizeClasses[form.fontSize] === 'text-sm' ? 'text-2xl' : 'text-3xl'}`}>{form.title}</h1>
                    <p className="mt-2 opacity-90">{form.description}</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    {form.fields.map(field => (
                        <div key={field.id}>
                            <label htmlFor={field.id} className="block font-medium mb-1">{field.label}{field.required && <span className="opacity-70">*</span>}</label>
                            {/* Render input based on type */}
                            <input 
                                type={field.type}
                                name={field.id} 
                                id={field.id} 
                                required={field.required}
                                placeholder={field.placeholder}
                                onChange={handleChange}
                                className="w-full p-2 rounded-md bg-black/10 border-black/20 focus:ring-2"
                                style={{ borderColor: form.buttonColor }}
                            />
                        </div>
                    ))}
                    <button
                        type="submit"
                        className="w-full p-3 font-bold rounded-md transition-opacity hover:opacity-90"
                        style={{ backgroundColor: form.buttonColor, color: form.buttonTextColor }}
                    >
                        {form.submitButtonText}
                    </button>
                </form>
            </div>
        </div>
    );
};