import React from 'react';
import { ChartBarIcon, Squares2x2Icon, UserGroupIcon, GlobeAltIcon, Cog6ToothIcon, BriefcaseIcon, ArrowPathRoundedSquareIcon, CalendarDaysIcon, CpuChipIcon, ClipboardDocumentCheckIcon, PlayIcon, ArrowLeftOnRectangleIcon, CheckCircleIcon, MegaphoneIcon, InboxIcon } from './icons';
import type { ViewType } from '../App';
import type { User } from '../types';

interface SidebarProps {
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  currentUser: User;
  onLogout: () => void;
}

const NavItem: React.FC<{
  viewName: ViewType;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}> = ({ viewName, currentView, setCurrentView, icon, children }) => {
  const isActive = currentView === viewName;
  return (
    <li>
        <a
            href="#"
            onClick={(e) => { e.preventDefault(); setCurrentView(viewName); }}
            className={`flex items-center p-3 rounded-lg text-base font-normal transition-all duration-200 ${
                isActive
                ? 'bg-primary-600 text-white shadow-md'
                : 'text-slate-500 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            >
            {icon}
            <span className="ml-3 flex-1 whitespace-nowrap">{children}</span>
        </a>
    </li>
  );
};

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView, currentUser, onLogout }) => {

  const mainNavItems = [
    { view: 'dashboard', icon: <ChartBarIcon className="w-6 h-6" />, label: 'Dashboard' },
    { view: 'conversations', icon: <InboxIcon className="w-6 h-6" />, label: 'Conversas' },
    { view: 'tasks', icon: <CheckCircleIcon className="w-6 h-6" />, label: 'Tarefas' },
    { view: 'kanban', icon: <Squares2x2Icon className="w-6 h-6" />, label: 'Kanban' },
    { view: 'clients', icon: <UserGroupIcon className="w-6 h-6" />, label: 'Clientes' },
    { view: 'services', icon: <BriefcaseIcon className="w-6 h-6" />, label: 'Serviços' },
    { view: 'subscriptions', icon: <ArrowPathRoundedSquareIcon className="w-6 h-6" />, label: 'Assinaturas' },
    { view: 'oneOffJobs', icon: <ClipboardDocumentCheckIcon className="w-6 h-6" />, label: 'Trabalhos Avulsos' },
    { view: 'automations', icon: <CpuChipIcon className="w-6 h-6" />, label: 'Automações' },
  ];

  const secondaryNavItems = [
      { view: 'marketingTools', icon: <MegaphoneIcon className="w-6 h-6" />, label: 'Ferramentas de Marketing' },
      { view: 'webview', icon: <GlobeAltIcon className="w-6 h-6" />, label: 'Webview' },
      { view: 'calendar', icon: <CalendarDaysIcon className="w-6 h-6" />, label: 'Calendário' },
      { view: 'settings', icon: <Cog6ToothIcon className="w-6 h-6" />, label: 'Configurações' },
  ];
  
  const agencyOnlyViews = ['automations'];

  return (
    <aside className="w-64 flex-shrink-0" aria-label="Sidebar">
        <div className="h-full px-3 py-4 overflow-y-auto bg-white dark:bg-slate-800 flex flex-col">
            <a href="#" onClick={(e) => e.preventDefault()} className="flex items-center pl-2.5 mb-5">
                <PlayIcon className="h-7 w-7 mr-2 text-primary-600" />
                <span className="self-center text-xl font-semibold whitespace-nowrap dark:text-white">Creapar Crm</span>
            </a>
            <ul className="space-y-2 flex-1">
                {mainNavItems.map(item => {
                    if (currentUser.role === 'client' && agencyOnlyViews.includes(item.view)) return null;
                    return (
                        <NavItem key={item.view} viewName={item.view as ViewType} currentView={currentView} setCurrentView={setCurrentView} icon={item.icon}>
                            {item.label}
                        </NavItem>
                    );
                })}
            </ul>
            <div className="pt-4 mt-4 space-y-2 border-t border-slate-200 dark:border-slate-700">
                {secondaryNavItems.map(item => {
                    return (
                        <NavItem key={item.view} viewName={item.view as ViewType} currentView={currentView} setCurrentView={setCurrentView} icon={item.icon}>
                            {item.label}
                        </NavItem>
                    );
                })}
                <li>
                    <button onClick={onLogout} className="w-full flex items-center p-3 rounded-lg text-slate-500 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700">
                        <ArrowLeftOnRectangleIcon className="w-6 h-6" />
                        <span className="ml-3 flex-1 whitespace-nowrap text-left">Log Out</span>
                    </button>
                </li>
            </div>
        </div>
    </aside>
  );
};