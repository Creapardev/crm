import React, { useMemo, useState } from 'react';
import type { Client, List, CustomFieldDefinition, Activity, Service, OneOffJob, Subscription, Account, User } from '../types';
import { UserGroupIcon, Squares2x2Icon, BanknotesIcon, TrophyIcon, DocumentDuplicateIcon, VideoCameraIcon, TableCellsIcon, SpeakerWaveIcon, DocumentTextIcon, ChartBarIcon, SparklesIcon } from './icons';
import { Modal } from './Modal';
import {
  BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Sector
} from 'recharts';

interface DashboardProps {
  currentUser: User;
  currentAccountId: string;
  accounts: Account[];
  allClients: Client[];
  allSubscriptions: Subscription[];
  allServices: Service[];
  allOneOffJobs: OneOffJob[];
  clients: Client[]; // Already filtered for current account
  lists: List[]; // Already filtered for current account
  customFields: CustomFieldDefinition[]; // Already filtered for current account
  subscriptions: Subscription[]; // Already filtered for current account
  services: Service[]; // Already filtered for current account
  oneOffJobs: OneOffJob[]; // Already filtered for current account
  analyzeClientPortfolio: () => Promise<string>;
}

const DonutChartLegend = ({ payload }: any) => {
  if (!payload) return null;
  return (
    <ul className="flex flex-col space-y-2">
      {payload.map((entry: any, index: number) => (
        <li key={`item-${index}`} className="flex items-center text-sm">
          <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: entry.color }} />
          <span className="text-slate-600 dark:text-slate-300 mr-auto">{entry.value}</span>
          <span className="font-medium text-slate-800 dark:text-slate-100">{entry.payload.payload.count}</span>
        </li>
      ))}
    </ul>
  );
};

const AgencyDashboard: React.FC<{
    accounts: Account[];
    allClients: Client[];
    allSubscriptions: Subscription[];
    allServices: Service[];
    analyzeClientPortfolio: () => Promise<string>;
}> = ({ accounts, allClients, allSubscriptions, allServices, analyzeClientPortfolio }) => {
    const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
    const [analysisResult, setAnalysisResult] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);

    const clientAccounts = accounts.filter(a => a.type === 'client');
    const totalClients = allClients.length;
    
    const totalRevenue = useMemo(() => {
        const serviceMap = new Map(allServices.map(s => [s.id, s.price]));
        return allSubscriptions
            .filter(sub => sub.status === 'active')
            .reduce((sum, sub) => sum + (serviceMap.get(sub.serviceId) || 0), 0);
    }, [allSubscriptions, allServices]);

    const handleAnalyze = async () => {
        setIsAnalysisModalOpen(true);
        setIsAiLoading(true);
        setAnalysisResult('');
        try {
            const result = await analyzeClientPortfolio();
            setAnalysisResult(result);
        } catch(e) {
            setAnalysisResult("Ocorreu um erro ao analisar o portfólio.");
            console.error(e);
        } finally {
            setIsAiLoading(false);
        }
    };
    
    return (
        <div className="space-y-6">
            <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Dashboard da Agência</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
                    <h3 className="font-semibold text-slate-900 dark:text-white">Contas de Clientes</h3>
                    <p className="text-3xl font-bold text-primary-600 mt-2">{clientAccounts.length}</p>
                </div>
                <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
                    <h3 className="font-semibold text-slate-900 dark:text-white">Total de Leads Gerenciados</h3>
                    <p className="text-3xl font-bold text-primary-600 mt-2">{totalClients}</p>
                </div>
                <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
                    <h3 className="font-semibold text-slate-900 dark:text-white">Receita Recorrente Total</h3>
                    <p className="text-3xl font-bold text-primary-600 mt-2">{totalRevenue.toLocaleString('pt-BR', {style: 'currency', currency: 'BRL'})}</p>
                </div>
            </div>
             <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Análise de Portfólio com IA</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Obtenha insights sobre seu portfólio de clientes para tomar decisões estratégicas.</p>
                <button onClick={handleAnalyze} className="mt-4 inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-lg shadow-sm hover:bg-primary-700">
                    <SparklesIcon className="w-5 h-5"/>
                    Analisar Portfólio com IA
                </button>
            </div>
            <Modal isOpen={isAnalysisModalOpen} onClose={() => setIsAnalysisModalOpen(false)} title="Análise de Portfólio por IA">
                 {isAiLoading ? (
                    <div className="text-center p-8">
                        <SparklesIcon className="w-12 h-12 text-primary-500 mx-auto animate-pulse" />
                        <p className="mt-4 text-slate-600 dark:text-slate-300">Analisando dados...</p>
                    </div>
                 ) : (
                    <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                        {analysisResult}
                    </div>
                 )}
            </Modal>
        </div>
    );
};


const ClientDashboard: React.FC<DashboardProps> = ({ clients, lists, customFields, subscriptions, services, oneOffJobs }) => {

  const dataByList = useMemo(() => {
    return lists.map(list => ({
      name: list.name,
      count: clients.filter(c => c.listId === list.id).length
    })).filter(item => item.count > 0);
  }, [clients, lists]);
  
  const leadSourceField = useMemo(() => customFields.find(f => f.name === 'Lead Source' && f.type === 'select'), [customFields]);

  const dataByLeadSource = useMemo(() => {
    if (!leadSourceField || !leadSourceField.options) return [];
    return leadSourceField.options.map(option => ({
      name: option,
      count: clients.filter(c => c.customFields[leadSourceField.id] === option).length
    })).filter(item => item.count > 0);
  }, [clients, leadSourceField]);

  const paidJobsValue = useMemo(() => {
    return oneOffJobs
        .filter(job => job.status === 'Pago')
        .reduce((sum, job) => sum + job.value, 0);
  }, [oneOffJobs]);
  
  const monthlyRevenue = useMemo(() => {
      const serviceMap = new Map(services.map(s => [s.id, s.price]));
      return subscriptions
          .filter(sub => sub.status === 'active')
          .reduce((sum, sub) => sum + (serviceMap.get(sub.serviceId) || 0), 0);
  }, [subscriptions, services]);

  const totalRevenue = paidJobsValue + monthlyRevenue;
  
  const CHART_COLORS = ['#3b82f6', '#ef4444', '#f97316', '#84cc16', '#14b8a6', '#a855f7'];

  const overviewMetrics = [
    { title: 'Total de Clientes', value: clients.length, icon: UserGroupIcon, color: 'text-blue-500' },
    { title: 'Receita Mensal', value: monthlyRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), icon: BanknotesIcon, color: 'text-green-500' },
    { title: 'Faturamento Total', value: totalRevenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }), icon: TrophyIcon, color: 'text-amber-500' },
  ];

  const activities: Activity[] = []; // Simplified for this refactoring

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      <div className="xl:col-span-2 space-y-6">
        <div>
            <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">Visão Geral</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {overviewMetrics.map(metric => (
                    <div key={metric.title} className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm flex items-center space-x-4">
                        <div className={`p-3 rounded-lg bg-slate-100 dark:bg-slate-700 ${metric.color}`}>
                            <metric.icon className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{metric.title}</p>
                            <p className="text-xl font-bold text-slate-900 dark:text-slate-100">{metric.value}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
            <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">Atividades Recentes</h2>
             <p className="text-sm text-slate-400">Atividades recentes aparecerão aqui.</p>
          </div>
          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
            <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">Análise de Fontes de Lead</h2>
             <ResponsiveContainer width="100%" height={250}>
                <BarChart data={dataByLeadSource} margin={{ top: 5, right: 0, left: 0, bottom: 5 }} barSize={20}>
                  <XAxis dataKey="name" scale="point" padding={{ left: 10, right: 10 }} tick={{ fill: 'currentColor' }} className="text-xs text-slate-500 dark:text-slate-400" />
                  <YAxis tick={{ fill: 'currentColor' }} className="text-xs text-slate-500 dark:text-slate-400" />
                  <Tooltip cursor={{fill: 'rgba(203, 213, 225, 0.3)'}} wrapperClassName="!text-sm rounded-lg shadow-lg !border-slate-200 dark:!bg-slate-700 dark:!border-slate-600" />
                  <Bar dataKey="count" background={{ fill: '#f1f5f9' }} radius={[4, 4, 0, 0]} className="fill-brand-light" />
                </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-sm">
            <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-4">Clientes por Etapa</h2>
            <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                    <Pie data={dataByList} dataKey="count" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={2}>
                        {dataByList.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} className="stroke-white dark:stroke-slate-800" strokeWidth={2}/>
                        ))}
                    </Pie>
                    <Tooltip />
                </PieChart>
            </ResponsiveContainer>
             <div className="mt-4">
                <DonutChartLegend payload={dataByList.map((entry, index) => ({
                    value: entry.name,
                    color: CHART_COLORS[index % CHART_COLORS.length],
                    payload: { payload: { count: entry.count } }
                }))} />
            </div>
        </div>
      </div>
    </div>
  );
};


export const Dashboard: React.FC<DashboardProps> = (props) => {
    const { currentUser, currentAccountId, accounts } = props;

    const isAgencyView = currentUser.role === 'agency' && currentAccountId === currentUser.accountId;

    if (isAgencyView) {
        return <AgencyDashboard 
                    accounts={accounts} 
                    allClients={props.allClients} 
                    allSubscriptions={props.allSubscriptions} 
                    allServices={props.allServices}
                    analyzeClientPortfolio={props.analyzeClientPortfolio}
                />;
    }

    return <ClientDashboard {...props} />;
};
