import React, { useState, useEffect } from 'react';
import type { CustomFieldDefinition, WebViewItem, CustomFieldType, List, User, Account } from '../types';
import { PlusIcon, TrashIcon, PencilIcon, BuildingOffice2Icon, SparklesIcon, CheckCircleIcon, ChatBubbleBottomCenterTextIcon } from './icons';
import { Modal } from './Modal';

interface SettingsProps {
  currentUser: User;
  accounts: Account[];
  users: User[];
  currentAccount?: Account;
  customFields: CustomFieldDefinition[];
  webViews: WebViewItem[];
  calendarUrl: string;
  lists: List[];
  addCustomField: (field: Omit<CustomFieldDefinition, 'id' | 'accountId'>) => void;
  deleteCustomField: (fieldId: string) => void;
  addWebView: (view: Omit<WebViewItem, 'id' | 'accountId'>) => void;
  deleteWebView: (viewId: string) => void;
  saveCalendarUrl: (url: string) => void;
  addList: (name: string) => void;
  updateList: (listId: string, newName: string) => void;
  deleteList: (listId: string) => void;
  addUserAndAccount: (accountName: string, userName: string, userEmail: string, userPassword: string) => {success: boolean, message: string};
  updateUserAccess: (userId: string, isActive: boolean) => void;
  resetUserPassword: (userId: string, newPassword: string) => void;
  deleteUserAndAccount: (accountId: string) => void;
  generateClientReport: (accountId: string) => Promise<string>;
  saveAccountApiKey: (accountId: string, apiKey: string) => Promise<{success: boolean; message: string}>;
  saveWhatsAppConfig: (accountId: string, config: { apiUrl: string; apiKey: string; instanceId: string; testNumber?: string; }) => Promise<{ success: boolean; message: string }>;
}

const WhatsAppApiManager: React.FC<{
    currentAccount: Account;
    saveWhatsAppConfig: (accountId: string, config: { apiUrl: string, apiKey: string, instanceId: string, testNumber?: string }) => Promise<{ success: boolean, message: string }>;
}> = ({ currentAccount, saveWhatsAppConfig }) => {
    const [config, setConfig] = useState({
        apiUrl: currentAccount.whatsappApiUrl || '',
        apiKey: currentAccount.whatsappApiKey || '',
        instanceId: currentAccount.whatsappInstanceId || '',
    });
    const [testNumber, setTestNumber] = useState('');
    const [status, setStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

    useEffect(() => {
        setConfig({
            apiUrl: currentAccount.whatsappApiUrl || '',
            apiKey: currentAccount.whatsappApiKey || '',
            instanceId: currentAccount.whatsappInstanceId || '',
        });
        setStatus(currentAccount.whatsappApiUrl ? 'success' : 'idle');
    }, [currentAccount]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setConfig(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus('testing');
        const result = await saveWhatsAppConfig(currentAccount.id, { ...config, testNumber });
        if (result.success) {
            setStatus('success');
        } else {
            setStatus('error');
        }
        alert(result.message);
    };
    
    return (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-1">Integração com WhatsApp</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-6">Conecte-se a um provedor de API do WhatsApp Business para enviar mensagens automáticas.</p>
            <form onSubmit={handleSave} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium">URL da API</label>
                    <input type="url" name="apiUrl" value={config.apiUrl} onChange={handleChange} placeholder="https://api.seuprovedor.com/v1/messages" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required/>
                </div>
                 <div>
                    <label className="block text-sm font-medium">Chave da API (API Key)</label>
                    <input type="password" name="apiKey" value={config.apiKey} onChange={handleChange} className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required/>
                </div>
                <div>
                    <label className="block text-sm font-medium">ID da Instância / Sender</label>
                    <input type="text" name="instanceId" value={config.instanceId} onChange={handleChange} className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required/>
                </div>
                <div className="p-4 border rounded-lg dark:border-slate-700 space-y-3">
                    <p className="text-sm font-medium">Validar Conexão (Opcional)</p>
                     <div>
                        <label className="block text-sm font-medium">Número de WhatsApp para Teste</label>
                        <input type="tel" value={testNumber} onChange={e => setTestNumber(e.target.value)} placeholder="5511999998888" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600"/>
                    </div>
                </div>
                 <button type="submit" disabled={status === 'testing'} className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 disabled:bg-slate-400">
                    {status === 'testing' ? 'Salvando e Testando...' : 'Salvar e Enviar Teste'}
                </button>
            </form>
        </div>
    );
};


const ApiKeyManager: React.FC<{
    currentAccount: Account;
    saveAccountApiKey: (accountId: string, apiKey: string) => Promise<{success: boolean; message: string}>;
}> = ({ currentAccount, saveAccountApiKey }) => {
    const [apiKey, setApiKey] = useState(currentAccount.geminiApiKey || '');
    const [status, setStatus] = useState<'idle' | 'validating' | 'valid' | 'invalid'>('idle');
    const [isHelpOpen, setIsHelpOpen] = useState(false);
    
    useEffect(() => {
        setApiKey(currentAccount.geminiApiKey || '');
        setStatus(currentAccount.geminiApiKey ? 'valid' : 'idle');
    }, [currentAccount.geminiApiKey]);

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus('validating');
        const result = await saveAccountApiKey(currentAccount.id, apiKey);
        if (result.success) {
            setStatus('valid');
        } else {
            setStatus('invalid');
        }
        alert(result.message);
    };
    
    const getStatusIndicator = () => {
        switch(status) {
            case 'valid': return <span className="text-xs font-medium text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/50 px-2 py-1 rounded-md">Chave Válida</span>;
            case 'invalid': return <span className="text-xs font-medium text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-900/50 px-2 py-1 rounded-md">Chave Inválida</span>;
            case 'validating': return <span className="text-xs font-medium text-slate-600 dark:text-slate-400">Validando...</span>;
            default: return <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Não configurada</span>;
        }
    }

    return (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
            <div className="flex justify-between items-start mb-1">
                <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Configuração de IA (Gemini)</h2>
                {getStatusIndicator()}
            </div>
            <p className="text-slate-500 dark:text-slate-400 mb-6">Insira sua chave de API do Google Gemini para habilitar as funcionalidades de IA.</p>
            <form onSubmit={handleSave} className="space-y-4">
                <div>
                    <label htmlFor="apiKey" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Sua Chave de API</label>
                    <input type="password" id="apiKey" value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="Cole sua chave de API aqui" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600"/>
                </div>
                <div className="flex items-center gap-4">
                    <button type="submit" disabled={status === 'validating'} className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700 disabled:bg-slate-400">
                        {status === 'validating' ? 'Validando...' : 'Salvar e Validar'}
                    </button>
                    <button type="button" onClick={() => setIsHelpOpen(true)} className="text-sm text-primary-600 dark:text-primary-400 hover:underline">
                        Como obter sua chave?
                    </button>
                </div>
            </form>
            <Modal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} title="Como obter sua Chave de API do Gemini">
                <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p>Você pode obter uma chave de API gratuita para o Gemini rapidamente. Siga estes passos:</p>
                    <ol>
                        <li>Acesse o <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-primary-500 hover:underline">Google AI Studio</a>.</li>
                        <li>Faça login com sua conta Google.</li>
                        <li>Clique em <strong>"Create API key in new project"</strong> (Criar chave de API em um novo projeto).</li>
                        <li>A chave será gerada. Copie a chave (é uma longa sequência de letras e números).</li>
                        <li>Cole a chave no campo de configuração do CRM e clique em "Salvar e Validar".</li>
                    </ol>
                    <p>Pronto! Suas funcionalidades de IA estarão ativas.</p>
                </div>
            </Modal>
        </div>
    );
};

const AccountManager: React.FC<{
  accounts: Account[],
  users: User[],
  addUserAndAccount: (accountName: string, userName: string, userEmail: string, userPassword: string) => {success: boolean, message: string};
  updateUserAccess: (userId: string, isActive: boolean) => void;
  resetUserPassword: (userId: string, newPassword: string) => void;
  deleteUserAndAccount: (accountId: string) => void;
  generateClientReport: (accountId: string) => Promise<string>;
}> = (props) => {
  const { accounts, users, addUserAndAccount, updateUserAccess, resetUserPassword, deleteUserAndAccount, generateClientReport } = props;
  
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<Account | null>(null);

  const [newAccountName, setNewAccountName] = useState('');
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');

  const clientAccounts = accounts.filter(a => a.type === 'client');

  const handleAddAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const result = addUserAndAccount(newAccountName, newUserName, newUserEmail, newUserPassword);
    if(result.success) {
      setNewAccountName('');
      setNewUserName('');
      setNewUserEmail('');
      setNewUserPassword('');
      setIsAddModalOpen(false);
    } else {
      alert(result.message);
    }
  };
  
  const handleDelete = () => {
    if (isDeleteModalOpen) {
      deleteUserAndAccount(isDeleteModalOpen.id);
      setIsDeleteModalOpen(null);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <BuildingOffice2Icon className="w-6 h-6 text-primary-600"/>
        <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciar Contas de Clientes</h2>
      </div>
      <p className="text-slate-500 dark:text-slate-400 mb-6">Crie, gerencie e pause o acesso aos portais de seus clientes.</p>
      <button onClick={() => setIsAddModalOpen(true)} className="mb-6 w-full sm:w-auto px-4 py-2 flex items-center justify-center gap-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700">
        <PlusIcon className="w-5 h-5"/> Criar Nova Conta de Cliente
      </button>

      <div className="space-y-3">
        {clientAccounts.map(account => {
            const user = users.find(u => u.accountId === account.id);
            if (!user) return null;
            return (
                <div key={account.id} className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg flex flex-wrap items-center justify-between gap-4">
                    <div>
                        <p className="font-semibold text-slate-800 dark:text-slate-200">{account.name}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{user.email}</p>
                    </div>
                    <div className="flex items-center gap-4">
                         <div className="flex items-center">
                            <span className="text-sm mr-2 text-slate-600 dark:text-slate-300">Acesso</span>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" checked={user.isActive} onChange={(e) => updateUserAccess(user.id, e.target.checked)} className="sr-only peer" />
                                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                            </label>
                        </div>
                        <button onClick={() => setIsDeleteModalOpen(account)} className="p-2 text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700">
                           <TrashIcon className="w-5 h-5"/>
                        </button>
                    </div>
                </div>
            )
        })}
      </div>

      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Criar Nova Conta de Cliente">
          <form onSubmit={handleAddAccount} className="space-y-4">
              <div>
                  <label className="block text-sm font-medium">Nome da Conta (Empresa)</label>
                  <input type="text" value={newAccountName} onChange={e => setNewAccountName(e.target.value)} required className="mt-1 block w-full rounded-md dark:bg-slate-700 dark:border-slate-600"/>
              </div>
               <div>
                  <label className="block text-sm font-medium">Nome do Usuário Principal</label>
                  <input type="text" value={newUserName} onChange={e => setNewUserName(e.target.value)} required className="mt-1 block w-full rounded-md dark:bg-slate-700 dark:border-slate-600"/>
              </div>
              <div>
                  <label className="block text-sm font-medium">Email do Usuário</label>
                  <input type="email" value={newUserEmail} onChange={e => setNewUserEmail(e.target.value)} required className="mt-1 block w-full rounded-md dark:bg-slate-700 dark:border-slate-600"/>
              </div>
              <div>
                  <label className="block text-sm font-medium">Senha Inicial</label>
                  <input type="password" value={newUserPassword} onChange={e => setNewUserPassword(e.target.value)} required className="mt-1 block w-full rounded-md dark:bg-slate-700 dark:border-slate-600"/>
              </div>
              <div className="flex justify-end pt-4 gap-2">
                  <button type="button" onClick={() => setIsAddModalOpen(false)} className="px-4 py-2 text-sm font-medium bg-white dark:bg-slate-600 border dark:border-slate-500 rounded-md">Cancelar</button>
                  <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md">Criar Conta</button>
              </div>
          </form>
      </Modal>

      <Modal isOpen={!!isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(null)} title={`Excluir conta de ${isDeleteModalOpen?.name}?`}>
          <div className="space-y-4">
              <p className="text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10 p-3 rounded-lg">
                  <span className="font-bold">Atenção:</span> Esta ação é irreversível. Ao excluir a conta, todos os dados associados a ela (clientes, tarefas, automações, etc.) serão permanentemente removidos.
              </p>
              <p>Se desejar apenas desativar o acesso temporariamente, feche esta janela e use o interruptor "Acesso".</p>
              <div className="flex justify-end pt-4 gap-2">
                  <button type="button" onClick={() => setIsDeleteModalOpen(null)} className="px-4 py-2 text-sm font-medium bg-white dark:bg-slate-600 border dark:border-slate-500 rounded-md">Cancelar</button>
                  <button type="button" onClick={handleDelete} className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md">Sim, excluir permanentemente</button>
              </div>
          </div>
      </Modal>
    </div>
  );
};


export const Settings: React.FC<SettingsProps> = (props) => {
  const {
    currentUser, accounts, users, currentAccount, customFields, webViews, calendarUrl, lists,
    addCustomField, deleteCustomField, addWebView, deleteWebView, saveCalendarUrl,
    addList, updateList, deleteList, generateClientReport,
    addUserAndAccount, updateUserAccess, resetUserPassword, deleteUserAndAccount,
    saveAccountApiKey, saveWhatsAppConfig
  } = props;

  // State for forms
  const [newFieldName, setNewFieldName] = useState('');
  const [newFieldType, setNewFieldType] = useState<CustomFieldType>('text');
  const [newFieldOptions, setNewFieldOptions] = useState('');
  const [newListName, setNewListName] = useState('');
  const [editingList, setEditingList] = useState<{ id: string; name: string } | null>(null);
  const [localCalendarUrl, setLocalCalendarUrl] = useState(calendarUrl);
  const [newWebViewTitle, setNewWebViewTitle] = useState('');
  const [newWebViewUrl, setNewWebViewUrl] = useState('');

  useEffect(() => {
    setLocalCalendarUrl(calendarUrl);
  }, [calendarUrl]);


  const handleAddField = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFieldName.trim()) return;
    const field: Omit<CustomFieldDefinition, 'id' | 'accountId'> = {
        name: newFieldName, type: newFieldType,
    };
    if (newFieldType === 'select' && newFieldOptions.trim()) {
        field.options = newFieldOptions.split(',').map(opt => opt.trim());
    }
    addCustomField(field);
    setNewFieldName(''); setNewFieldType('text'); setNewFieldOptions('');
  };

  const handleAddList = (e: React.FormEvent) => { e.preventDefault(); if (newListName.trim()) { addList(newListName.trim()); setNewListName(''); } };
  const handleUpdateList = () => { if (editingList && editingList.name.trim()) { updateList(editingList.id, editingList.name.trim()); setEditingList(null); } };
  
  const handleSaveCalendar = (e: React.FormEvent) => {
    e.preventDefault();
    saveCalendarUrl(localCalendarUrl);
    alert('URL do Calendário salva!');
  };

  const handleAddWebView = (e: React.FormEvent) => {
    e.preventDefault();
    if (newWebViewTitle.trim() && newWebViewUrl.trim()) {
      addWebView({ title: newWebViewTitle, url: newWebViewUrl });
      setNewWebViewTitle('');
      setNewWebViewUrl('');
    }
  };


  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200">Configurações</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {currentUser.role === 'agency' && (
            <div className="lg:col-span-2">
                <AccountManager 
                  accounts={accounts} 
                  users={users} 
                  addUserAndAccount={addUserAndAccount} 
                  updateUserAccess={updateUserAccess}
                  resetUserPassword={resetUserPassword}
                  deleteUserAndAccount={deleteUserAndAccount}
                  generateClientReport={generateClientReport}
                />
            </div>
          )}
          
          {currentAccount && (
            <>
                <ApiKeyManager currentAccount={currentAccount} saveAccountApiKey={saveAccountApiKey} />
                <WhatsAppApiManager currentAccount={currentAccount} saveWhatsAppConfig={saveWhatsAppConfig} />
            </>
          )}

          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-1">Campos Personalizados</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-6">Defina pontos de dados para seus clientes.</p>
            <form onSubmit={handleAddField} className="space-y-4 items-end mb-6 p-4 border rounded-lg dark:border-slate-700">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                     <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Nome do Campo</label>
                        <input type="text" value={newFieldName} onChange={e => setNewFieldName(e.target.value)} placeholder="Ex: Tamanho da Empresa" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required/>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Tipo do Campo</label>
                        <select value={newFieldType} onChange={e => setNewFieldType(e.target.value as CustomFieldType)} className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600">
                            <option value="text">Texto</option>
                            <option value="number">Número</option>
                            <option value="date">Data</option>
                            <option value="select">Seleção</option>
                        </select>
                    </div>
                </div>
                {newFieldType === 'select' && (
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Opções (separadas por vírgula)</label>
                        <input type="text" value={newFieldOptions} onChange={e => setNewFieldOptions(e.target.value)} placeholder="Opção 1, Opção 2" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600"/>
                    </div>
                )}
                 <button type="submit" className="w-full justify-center px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700">
                    <PlusIcon className="w-5 h-5"/> Adicionar Campo
                </button>
            </form>
            <ul className="space-y-2">
                {customFields.map(field => (
                    <li key={field.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                        <div>
                          <span className="font-medium text-slate-800 dark:text-slate-200">{field.name}</span>
                          <span className="ml-2 text-xs text-white bg-slate-400 dark:bg-slate-600 px-2 py-0.5 rounded-full">{field.type}</span>
                        </div>
                        <button onClick={() => deleteCustomField(field.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"><TrashIcon className="w-5 h-5"/></button>
                    </li>
                ))}
            </ul>
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-1">Etapas do Kanban</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-6">Personalize as colunas do painel Kanban.</p>
            <form onSubmit={handleAddList} className="flex items-end gap-4 mb-6 p-4 border rounded-lg dark:border-slate-700">
                <div className="flex-grow">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Nome da Etapa</label>
                    <input type="text" value={newListName} onChange={e => setNewListName(e.target.value)} placeholder="Ex: Contratado" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required/>
                </div>
                <button type="submit" className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700">
                    <PlusIcon className="w-4 h-4"/>
                </button>
            </form>
            <ul className="space-y-2">
                {lists.map(list => (
                    <li key={list.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                        {editingList?.id === list.id ? (
                            <div className="flex-grow flex items-center gap-2">
                                <input
                                    type="text" value={editingList.name}
                                    onChange={(e) => setEditingList({ ...editingList, name: e.target.value })}
                                    onKeyDown={(e) => e.key === 'Enter' && handleUpdateList()}
                                    onBlur={handleUpdateList} autoFocus
                                    className="block w-full rounded-md sm:text-sm dark:bg-slate-600 dark:border-slate-500"
                                />
                            </div>
                        ) : (
                            <>
                                <span className="font-medium text-slate-800 dark:text-slate-200">{list.name}</span>
                                <div className="flex items-center gap-2">
                                    <button onClick={() => setEditingList({ id: list.id, name: list.name })} className="text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300">
                                        <PencilIcon className="w-4 h-4"/>
                                    </button>
                                    <button onClick={() => deleteList(list.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                                        <TrashIcon className="w-4 h-4"/>
                                    </button>
                                </div>
                            </>
                        )}
                    </li>
                ))}
            </ul>
          </div>
          
           {/* Calendar Integration */}
           <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-1">Integração com Calendário Google</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-6">Integre seu Google Agenda para visualizar seus eventos no CRM.</p>
            <form onSubmit={handleSaveCalendar} className="space-y-4">
                <div>
                    <label htmlFor="calendarUrl" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Endereço público no formato iCal</label>
                    <input type="url" id="calendarUrl" value={localCalendarUrl} onChange={e => setLocalCalendarUrl(e.target.value)} placeholder="https://calendar.google.com/..." className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" />
                    <p className="text-xs text-slate-400 mt-2">No Google Agenda, vá para Configurações da agenda {'>'} Integrar agenda.</p>
                </div>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700">Salvar URL</button>
            </form>
           </div>
           
           {/* Webview URLs */}
           <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm">
                <h2 className="text-xl font-semibold text-slate-900 dark:text-white mb-1">URLs de Webview</h2>
                <p className="text-slate-500 dark:text-slate-400 mb-6">Adicione URLs para incorporar na área de Webview.</p>
                <form onSubmit={handleAddWebView} className="space-y-4 mb-6 p-4 border rounded-lg dark:border-slate-700">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Título</label>
                            <input type="text" value={newWebViewTitle} onChange={e => setNewWebViewTitle(e.target.value)} placeholder="Ex: Analytics" className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">URL</label>
                            <input type="url" value={newWebViewUrl} onChange={e => setNewWebViewUrl(e.target.value)} placeholder="https://..." className="mt-1 block w-full rounded-md sm:text-sm dark:bg-slate-700 dark:border-slate-600" required />
                        </div>
                    </div>
                    <button type="submit" className="w-full justify-center px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 rounded-md shadow-sm hover:bg-primary-700">
                        <PlusIcon className="w-5 h-5" /> Adicionar URL
                    </button>
                </form>
                <ul className="space-y-2">
                    {webViews.map(view => (
                        <li key={view.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                            <div>
                                <p className="font-medium text-slate-800 dark:text-slate-200">{view.title}</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400 truncate max-w-xs">{view.url}</p>
                            </div>
                            <button onClick={() => deleteWebView(view.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </li>
                    ))}
                </ul>
           </div>
      </div>
    </div>
  );
};