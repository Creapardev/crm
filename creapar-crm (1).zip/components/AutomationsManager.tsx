import React, { useState, useEffect } from 'react';
import type { Automation, TriggerType, List, Subscription, ActionType, Condition, ConditionOperator, CustomFieldDefinition, OneOffJob, AutomationAction, DelayAction } from '../types';
import { Modal } from './Modal';
import { PlusIcon, TrashIcon, PencilIcon, SparklesIcon, ClockIcon, ChatBubbleBottomCenterTextIcon, CpuChipIcon } from './icons';

interface AutomationsManagerProps {
  automations: Automation[];
  lists: List[];
  customFields: CustomFieldDefinition[];
  addAutomation: (automation: Omit<Automation, 'id' | 'accountId'>) => void;
  updateAutomation: (automation: Automation) => void;
  deleteAutomation: (automationId: string) => void;
  isAiAvailable: boolean;
  generateWhatsAppTemplate: (objective: string) => Promise<string>;
  generateDripCampaign: (objective: string) => Promise<Omit<Automation, 'id'|'accountId'|'enabled'>>;
}

const triggerTypeLabels: Record<TriggerType, string> = {
    new_client_created: 'Novo cliente criado',
    client_moved_to_list: 'Cliente movido para etapa',
    new_subscription_created: 'Nova assinatura criada',
    subscription_status_changed: 'Status da assinatura alterado',
    one_off_job_status_changed: 'Status do trabalho avulso alterado',
    scheduled_weekly_check: 'Verificação Semanal Programada',
};

const actionTypeLabels: Record<ActionType, string> = {
    webhook: 'Chamar um Webhook',
    create_task: 'Criar uma Tarefa',
    update_field: 'Atualizar Campo do Cliente',
    move_client: 'Mover Cliente para Etapa',
    send_whatsapp: 'Enviar Mensagem no WhatsApp',
    delay: 'Aguardar (Delay)',
};

const ActionIcon: React.FC<{type: ActionType}> = ({type}) => {
    switch(type) {
        case 'send_whatsapp': return <ChatBubbleBottomCenterTextIcon className="w-5 h-5"/>;
        case 'delay': return <ClockIcon className="w-5 h-5"/>;
        default: return <CpuChipIcon className="w-5 h-5"/>;
    }
}

const AutomationForm: React.FC<{
  onSave: (automationData: Omit<Automation, 'id' | 'accountId'> | Automation) => void;
  onClose: () => void;
  initialData?: Automation | null;
  lists: List[];
  customFields: CustomFieldDefinition[];
  isAiAvailable: boolean;
  generateWhatsAppTemplate: (objective: string) => Promise<string>;
}> = ({ onSave, onClose, initialData, lists, customFields, isAiAvailable, generateWhatsAppTemplate }) => {
  const [formData, setFormData] = useState<Omit<Automation, 'id' | 'accountId'> | Automation>(() => {
    return initialData ? JSON.parse(JSON.stringify(initialData)) : { 
        name: '',
        triggerType: 'new_client_created',
        triggerFilters: {},
        conditions: [],
        actions: [],
        enabled: true,
    };
  });
  
  const [whatsAppGenObjective, setWhatsAppGenObjective] = useState('');
  const [isAiWhatsAppLoading, setIsAiWhatsAppLoading] = useState(false);
  const [aiWhatsAppTargetIndex, setAiWhatsAppTargetIndex] = useState<number | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleTriggerFilterChange = (key: 'listId' | 'status', value: string) => {
    setFormData(prev => ({
        ...prev,
        triggerFilters: {
            ...prev.triggerFilters,
            [key]: value
        }
    }));
  };
  
  const addAction = (type: ActionType) => {
      if (!type) return;
      let newAction: AutomationAction;
      const phoneField = customFields.find(f => f.name.toLowerCase().includes('whatsapp'))?.id;

      switch(type) {
        case 'create_task': newAction = { type: 'create_task', titleTemplate: 'Fazer follow-up com {{client.name}}', dueDays: 3 }; break;
        case 'update_field': newAction = { type: 'update_field', fieldId: customFields[0]?.id || '', valueTemplate: '' }; break;
        case 'move_client': newAction = { type: 'move_client', targetListId: lists[0]?.id || '' }; break;
        case 'send_whatsapp': newAction = { type: 'send_whatsapp', phoneFieldId: phoneField || '', messageTemplate: 'Olá {{client.name}}, ' }; break;
        case 'delay': newAction = { type: 'delay', days: 1 }; break;
        default: newAction = { type: 'webhook', url: '', method: 'POST', bodyTemplate: '' }; break;
      }
      setFormData(p => ({...p, actions: [...p.actions, newAction]}));
  }

  const updateAction = (index: number, updatedAction: AutomationAction) => {
      const newActions = [...formData.actions];
      newActions[index] = updatedAction;
      setFormData(p => ({...p, actions: newActions}));
  }
  
  const removeAction = (index: number) => {
      setFormData(p => ({...p, actions: p.actions.filter((_, i) => i !== index)}));
  }

  const handleGenerateTemplate = async () => {
      if (!whatsAppGenObjective.trim() || aiWhatsAppTargetIndex === null) return;
      setIsAiWhatsAppLoading(true);
      try {
          const template = await generateWhatsAppTemplate(whatsAppGenObjective);
          const currentAction = formData.actions[aiWhatsAppTargetIndex];
          if (currentAction.type === 'send_whatsapp') {
              updateAction(aiWhatsAppTargetIndex, { ...currentAction, messageTemplate: template });
          }
      } catch (e) {
          console.error(e);
          alert("Falha ao gerar template de mensagem.");
      } finally {
          setIsAiWhatsAppLoading(false);
          setAiWhatsAppTargetIndex(null);
          setWhatsAppGenObjective('');
      }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };
  
  const renderTriggerFilters = () => {
    switch (formData.triggerType) {
        case 'client_moved_to_list':
            return (
                <div>
                    <label className="text-sm">Etapa de Destino</label>
                    <select value={formData.triggerFilters?.listId || ''} onChange={e => handleTriggerFilterChange('listId', e.target.value)} className="w-full text-sm rounded-md dark:bg-slate-600">
                        {lists.map(list => <option key={list.id} value={list.id}>{list.name}</option>)}
                    </select>
                </div>
            );
        case 'subscription_status_changed':
            return (
                 <div>
                    <label className="text-sm">Para o Status</label>
                    <select value={formData.triggerFilters?.status || ''} onChange={e => handleTriggerFilterChange('status', e.target.value)} className="w-full text-sm rounded-md dark:bg-slate-600">
                        <option value="active">Ativa</option>
                        <option value="paused">Pausada</option>
                        <option value="cancelled">Cancelada</option>
                    </select>
                </div>
            );
         case 'one_off_job_status_changed':
            return (
                 <div>
                    <label className="text-sm">Para o Status</label>
                    <select value={formData.triggerFilters?.status || ''} onChange={e => handleTriggerFilterChange('status', e.target.value)} className="w-full text-sm rounded-md dark:bg-slate-600">
                        <option value="Pendente">Pendente</option>
                        <option value="Em Andamento">Em Andamento</option>
                        <option value="Concluído">Concluído</option>
                        <option value="Pago">Pago</option>
                    </select>
                </div>
            );
        default:
            return null;
    }
  };
  
  const renderActionForm = (action: AutomationAction, index: number) => {
    switch(action.type) {
        case 'delay':
            return (
                <div className="flex items-center gap-2">
                    <input type="number" value={action.days} onChange={e => updateAction(index, {...action, days: parseInt(e.target.value) || 1})} min="1" className="w-24 rounded-md sm:text-sm dark:bg-slate-600"/>
                    <span className="text-sm">dias</span>
                </div>
            );
        case 'send_whatsapp':
            return (
                <div className="space-y-2">
                    <div>
                        <label className="text-xs font-medium">Campo de Telefone</label>
                        <select value={action.phoneFieldId} onChange={e => updateAction(index, {...action, phoneFieldId: e.target.value})} className="w-full text-sm rounded-md dark:bg-slate-600">
                            {customFields.filter(f=>f.type==='text').map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="text-xs font-medium">Template da Mensagem</label>
                        <textarea value={action.messageTemplate} onChange={e => updateAction(index, {...action, messageTemplate: e.target.value})} rows={4} className="w-full text-sm rounded-md dark:bg-slate-600"></textarea>
                         {isAiAvailable && <button type="button" onClick={() => setAiWhatsAppTargetIndex(index)} className="text-xs text-primary-500 flex items-center gap-1"><SparklesIcon className="w-4 h-4"/> Gerar com IA</button>}
                    </div>
                </div>
            );
        case 'create_task':
            return (
                <div className="space-y-2">
                    <div>
                        <label className="text-xs font-medium">Título da Tarefa</label>
                        <input type="text" value={action.titleTemplate} onChange={e => updateAction(index, {...action, titleTemplate: e.target.value})} className="w-full text-sm rounded-md dark:bg-slate-600"/>
                    </div>
                    <div className="flex items-center gap-2">
                        <label className="text-xs font-medium">Vencimento em</label>
                        <input type="number" value={action.dueDays} onChange={e => updateAction(index, {...action, dueDays: parseInt(e.target.value)})} min="0" className="w-20 rounded-md sm:text-sm dark:bg-slate-600"/>
                        <span className="text-sm">dias</span>
                    </div>
                </div>
            );
        case 'move_client':
            return (
                <div>
                    <label className="text-xs font-medium">Mover para a etapa</label>
                    <select value={action.targetListId} onChange={e => updateAction(index, {...action, targetListId: e.target.value})} className="w-full text-sm rounded-md dark:bg-slate-600">
                        {lists.map(list => <option key={list.id} value={list.id}>{list.name}</option>)}
                    </select>
                </div>
            );
        default:
            return <p className="text-xs text-slate-400">Esta ação não possui configurações adicionais.</p>;
    }
  }


  return (
    <>
    <form onSubmit={handleSubmit} className="space-y-6">
        <div>
            <label className="block text-sm font-medium">Nome da Automação</label>
            <input type="text" name="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full rounded-md dark:bg-slate-700"/>
        </div>

        <div className="p-4 border rounded-md dark:border-slate-700 space-y-4">
            <h4 className="font-semibold text-slate-800 dark:text-slate-200">Gatilho (Quando isso acontecer...)</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label className="text-sm">Gatilho</label>
                    <select name="triggerType" value={formData.triggerType} onChange={handleChange} className="w-full text-sm rounded-md dark:bg-slate-600">
                        {Object.entries(triggerTypeLabels).map(([type, label]) => <option key={type} value={type}>{label}</option>)}
                    </select>
                </div>
                {renderTriggerFilters()}
            </div>
        </div>

        {/* TODO: Conditions UI */}

        <div className="p-4 border rounded-md dark:border-slate-700 space-y-4">
          <h4 className="font-semibold text-slate-800 dark:text-slate-200">Ações (Então faça isso...)</h4>
          <div className="space-y-3">
              {formData.actions.map((action, index) => (
                  <div key={index} className="p-3 border rounded-lg dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50">
                      <div className="flex justify-between items-center mb-3">
                          <div className="flex items-center gap-2 text-sm font-semibold">
                             <ActionIcon type={action.type} />
                             {actionTypeLabels[action.type]}
                          </div>
                          <button type="button" onClick={() => removeAction(index)}><TrashIcon className="w-4 h-4 text-red-500"/></button>
                      </div>
                      {renderActionForm(action, index)}
                  </div>
              ))}
          </div>
          <div className="relative">
              <select onChange={e => {addAction(e.target.value as ActionType); e.target.value = '';} } value="" className="text-sm rounded-md dark:bg-slate-700 w-full appearance-none p-2">
                  <option value="" disabled>+ Adicionar Ação</option>
                  {Object.entries(actionTypeLabels).map(([type, label]) => <option key={type} value={type}>{label}</option>)}
              </select>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-4">
            <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium bg-white dark:bg-slate-600 border dark:border-slate-500 rounded-md">Cancelar</button>
            <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md">Salvar Automação</button>
        </div>
    </form>
    <Modal isOpen={aiWhatsAppTargetIndex !== null} onClose={() => setAiWhatsAppTargetIndex(null)} title="Gerar mensagem com IA">
        <div className="space-y-3">
            <label className="text-sm">Descreva o objetivo da mensagem:</label>
            <input type="text" value={whatsAppGenObjective} onChange={e => setWhatsAppGenObjective(e.target.value)} placeholder="Ex: Mensagem de boas-vindas" className="w-full rounded-md dark:bg-slate-700"/>
            <button onClick={handleGenerateTemplate} disabled={isAiWhatsAppLoading} className="px-4 py-2 text-white bg-primary-600 rounded-md">
                {isAiWhatsAppLoading ? 'Gerando...' : 'Gerar Template'}
            </button>
        </div>
    </Modal>
    </>
  );
};


export const AutomationsManager: React.FC<AutomationsManagerProps> = (props) => {
  const { automations, addAutomation, updateAutomation, deleteAutomation, generateDripCampaign } = props;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAutomation, setEditingAutomation] = useState<Automation | null>(null);
  const [isAiDripModalOpen, setIsAiDripModalOpen] = useState(false);
  const [dripObjective, setDripObjective] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleOpenModal = (automation: Automation | null = null) => {
      setEditingAutomation(automation);
      setIsModalOpen(true);
  };
  
  const handleGenerateDrip = async () => {
      if(!dripObjective.trim()) return;
      setIsAiLoading(true);
      try {
          const campaignData = await generateDripCampaign(dripObjective);
          // The data from AI is partial, so we cast it to Automation for the form
          // The form will handle the rest of the fields.
          setEditingAutomation({ ...campaignData, id: '', accountId: '', enabled: true } as Automation);
          setIsAiDripModalOpen(false);
          setIsModalOpen(true);
      } catch (e) {
          console.error(e);
          alert('Falha ao gerar campanha.');
      } finally {
          setIsAiLoading(false);
          setDripObjective('');
      }
  }

  const handleSaveAutomation = (automationData: Omit<Automation, 'id' | 'accountId'> | Automation) => {
      if ('id' in automationData && automationData.id) {
          updateAutomation(automationData);
      } else {
          addAutomation(automationData);
      }
      setIsModalOpen(false);
      setEditingAutomation(null);
  }

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciamento de Automações</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Crie fluxos de trabalho para automatizar suas tarefas.</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setIsAiDripModalOpen(true)} disabled={!props.isAiAvailable} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-purple-600 rounded-lg shadow-sm hover:bg-purple-700 disabled:bg-slate-400 disabled:cursor-not-allowed">
                <SparklesIcon className="w-5 h-5"/> Gerar Campanha com IA
            </button>
            <button onClick={() => handleOpenModal(null)} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 rounded-lg shadow-sm hover:bg-primary-700">
                <PlusIcon className="w-5 h-5"/> Criar Automação
            </button>
          </div>
        </div>
        
        <div className="space-y-4">
            {automations.map(auto => (
                <div key={auto.id} className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="font-semibold text-slate-800 dark:text-slate-200">{auto.name}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                                Gatilho: <span className="font-medium">{triggerTypeLabels[auto.triggerType]}</span>
                            </p>
                            <div className="mt-2 flex flex-wrap gap-2 items-center">
                                {auto.actions.map((action, index) => (
                                    <React.Fragment key={index}>
                                        <div className="flex items-center gap-1 text-xs bg-slate-200 dark:bg-slate-600 px-2 py-1 rounded-full">
                                            <ActionIcon type={action.type} />
                                            <span>{actionTypeLabels[action.type]}</span>
                                        </div>
                                        {index < auto.actions.length - 1 && <span className="text-slate-400">&rarr;</span>}
                                    </React.Fragment>
                                ))}
                            </div>
                        </div>
                        <div className="flex items-center gap-3">
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" checked={auto.enabled} onChange={(e) => updateAutomation({...auto, enabled: e.target.checked})} className="sr-only peer" />
                                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-600 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                            </label>
                            <button onClick={() => handleOpenModal(auto)} className="text-primary-600 hover:text-primary-800"><PencilIcon className="w-5 h-5"/></button>
                            <button onClick={() => deleteAutomation(auto.id)} className="text-red-500 hover:text-red-700"><TrashIcon className="w-5 h-5"/></button>
                        </div>
                    </div>
                </div>
            ))}
        </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingAutomation ? 'Editar Automação' : 'Criar Nova Automação'}>
        <AutomationForm {...props} onSave={handleSaveAutomation} onClose={() => setIsModalOpen(false)} initialData={editingAutomation} />
      </Modal>

      <Modal isOpen={isAiDripModalOpen} onClose={() => setIsAiDripModalOpen(false)} title="Gerar Campanha de Drip com IA">
          <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium">Descreva o objetivo da campanha:</label>
                <input type="text" value={dripObjective} onChange={e => setDripObjective(e.target.value)} placeholder="Ex: Nutrição de lead após envio de proposta" className="mt-1 w-full rounded-md dark:bg-slate-700"/>
              </div>
              <div className="flex justify-end">
                <button onClick={handleGenerateDrip} disabled={isAiLoading || !dripObjective.trim()} className="px-4 py-2 text-white bg-primary-600 rounded-md disabled:bg-slate-400">
                    {isAiLoading ? 'Gerando...' : 'Gerar Campanha'}
                </button>
              </div>
          </div>
      </Modal>
    </div>
  );
};