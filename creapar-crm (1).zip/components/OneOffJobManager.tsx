import React, { useState, useMemo } from 'react';
import type { OneOffJob, Client } from '../types';
import { Modal } from './Modal';
import { PlusIcon, TrashIcon, PencilIcon } from './icons';

interface OneOffJobManagerProps {
  oneOffJobs: OneOffJob[];
  clients: Client[];
  addOneOffJob: (job: Omit<OneOffJob, 'id' | 'createdAt' | 'accountId'>) => void;
  updateOneOffJob: (job: OneOffJob) => void;
  deleteOneOffJob: (jobId: string) => void;
}

const jobStatuses: OneOffJob['status'][] = ['Pendente', 'Em Andamento', 'Concluído', 'Pago'];

const OneOffJobForm: React.FC<{
  clients: Client[];
  onSave: (jobData: Omit<OneOffJob, 'id' | 'createdAt' | 'accountId'> | OneOffJob) => void;
  onClose: () => void;
  initialData?: OneOffJob | null;
}> = ({ clients, onSave, onClose, initialData }) => {
  const [formData, setFormData] = useState<Omit<OneOffJob, 'id' | 'createdAt' | 'accountId'> | OneOffJob>(() => {
    return initialData || { 
        clientId: '', 
        title: '', 
        description: '', 
        value: 0,
        dueDate: new Date().toISOString().split('T')[0], 
        status: 'Pendente' 
    };
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ 
        ...prev, 
        [name]: type === 'number' ? parseFloat(value) || 0 : value 
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientId) {
        alert("Por favor, selecione um cliente.");
        return;
    }
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="clientId" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Cliente</label>
          <select name="clientId" id="clientId" value={formData.clientId} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            <option value="">Selecione um cliente</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Título do Trabalho</label>
          <input type="text" name="title" id="title" value={formData.title} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
        </div>
      </div>
      <div>
          <label htmlFor="description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Descrição</label>
          <textarea name="description" id="description" value={formData.description} onChange={handleChange} rows={3} className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"></textarea>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label htmlFor="value" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Valor (R$)</label>
          <input type="number" name="value" id="value" value={formData.value} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
        </div>
        <div>
          <label htmlFor="dueDate" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Data de Vencimento</label>
          <input type="date" name="dueDate" id="dueDate" value={formData.dueDate} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
        </div>
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Status</label>
          <select name="status" id="status" value={formData.status} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            {jobStatuses.map(status => <option key={status} value={status}>{status}</option>)}
          </select>
        </div>
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 focus:outline-none dark:bg-slate-600 dark:text-slate-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancelar</button>
        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Salvar Trabalho</button>
      </div>
    </form>
  );
};

export const OneOffJobManager: React.FC<OneOffJobManagerProps> = ({ oneOffJobs, clients, addOneOffJob, updateOneOffJob, deleteOneOffJob }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<OneOffJob | null>(null);

  const clientMap = useMemo(() => new Map(clients.map(c => [c.id, c.name])), [clients]);

  const handleOpenModal = (job: OneOffJob | null = null) => {
    setEditingJob(job);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingJob(null);
  };

  const handleSaveJob = (jobData: Omit<OneOffJob, 'id' | 'createdAt' | 'accountId'> | OneOffJob) => {
    if ('id' in jobData) {
      updateOneOffJob(jobData as OneOffJob);
    } else {
      addOneOffJob(jobData as Omit<OneOffJob, 'id' | 'createdAt' | 'accountId'>);
    }
    handleCloseModal();
  };
  
  const getStatusChip = (status: OneOffJob['status']) => {
    const baseClasses = "px-2 inline-flex text-xs leading-5 font-semibold rounded-full";
    switch (status) {
        case 'Pendente': return `${baseClasses} bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200`;
        case 'Em Andamento': return `${baseClasses} bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200`;
        case 'Concluído': return `${baseClasses} bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-200`;
        case 'Pago': return `${baseClasses} bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200`;
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciamento de Trabalhos Avulsos</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Gerencie serviços e pagamentos únicos.</p>
          </div>
          <button onClick={() => handleOpenModal()} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-lg shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
            <PlusIcon className="w-5 h-5"/>
            Novo Trabalho
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Cliente</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Título</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Valor</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Vencimento</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Status</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {oneOffJobs.map(job => (
                  <tr key={job.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{clientMap.get(job.clientId) || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">{job.title}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">
                        {job.value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">{new Date(job.dueDate).toLocaleDateString('pt-BR', {timeZone: 'UTC'})}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm"><span className={getStatusChip(job.status)}>{job.status}</span></td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                      <button onClick={() => handleOpenModal(job)} className="text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300">
                        <PencilIcon className="w-5 h-5"/>
                      </button>
                      <button onClick={() => deleteOneOffJob(job.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                        <TrashIcon className="w-5 h-5"/>
                      </button>
                    </td>
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingJob ? 'Editar Trabalho' : 'Novo Trabalho Avulso'}>
        <OneOffJobForm 
          clients={clients}
          onSave={handleSaveJob} 
          onClose={handleCloseModal} 
          initialData={editingJob} 
        />
      </Modal>
    </div>
  );
};