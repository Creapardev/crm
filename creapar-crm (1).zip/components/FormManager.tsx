import React, { useState, useEffect } from 'react';
import type { Form, CustomFieldDefinition, List, FormField, FormFieldType } from '../types';
import { Modal } from './Modal';
import { PlusIcon, TrashIcon, PencilIcon, SparklesIcon, DocumentDuplicateIcon } from './icons';

interface FormManagerProps {
  forms: Form[];
  customFields: CustomFieldDefinition[];
  lists: List[];
  addForm: (form: Omit<Form, 'id' | 'createdAt' | 'accountId'>) => void;
  updateForm: (form: Form) => void;
  deleteForm: (formId: string) => void;
  isAiAvailable: boolean;
  generateFormSuggestions: (objective: string) => Promise<{ title: string, fieldIds: string[] } | null>;
}

const FormBuilder: React.FC<{
    initialData?: Form | Omit<Form, 'id' | 'createdAt' | 'accountId'> | null,
    onSave: (formData: Omit<Form, 'id' | 'createdAt' | 'accountId'> | Form) => void,
    onClose: () => void,
    customFields: CustomFieldDefinition[],
    lists: List[],
}> = ({ initialData, onSave, onClose, customFields, lists }) => {
    const [formData, setFormData] = useState<Omit<Form, 'id' | 'createdAt' | 'accountId'> | Form>(() => {
        return initialData || {
            name: '',
            title: '',
            description: '',
            fields: [],
            destinationListId: lists[0]?.id || '',
            submitButtonText: 'Enviar',
            backgroundColor: '#ffffff',
            textColor: '#0f172a',
            buttonColor: '#4f46e5',
            buttonTextColor: '#ffffff',
            fontSize: 'md',
        };
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFieldToggle = (fieldId: string) => {
        const fieldDef = customFields.find(f => f.id === fieldId);
        const baseField = [ {id: 'name', label: 'Nome', type: 'text'}, {id: 'email', label: 'Email', type: 'email'} ].find(f => f.id === fieldId);

        let newField: FormField | undefined;
        
        if (fieldDef) {
            newField = {
                id: `form-field-${fieldDef.id}`,
                label: fieldDef.name,
                type: fieldDef.type,
                required: false,
                placeholder: `Seu ${fieldDef.name.toLowerCase()}`,
                mapsToClientField: fieldDef.id,
                options: fieldDef.options,
            };
        } else if (baseField) {
            newField = {
                id: `form-field-${baseField.id}`,
                label: baseField.label,
                type: baseField.type as any,
                required: true,
                placeholder: `Seu ${baseField.label.toLowerCase()}`,
                mapsToClientField: baseField.id,
            };
        }
        
        if (!newField) return;

        setFormData(prev => {
            const fieldExists = prev.fields.some(f => f.mapsToClientField === fieldId);
            if (fieldExists) {
                return { ...prev, fields: prev.fields.filter(f => f.mapsToClientField !== fieldId) };
            } else {
                return { ...prev, fields: [...prev.fields, newField!] };
            }
        });
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!formData.destinationListId && lists.length > 0) {
            alert("Por favor, selecione uma lista de destino.");
            return;
        }
        onSave(formData);
    }

    const allPossibleFields = [
        { name: 'Nome', id: 'name', type: 'text' },
        { name: 'Email', id: 'email', type: 'email' },
        ...customFields.map(f => ({ name: f.name, id: f.id, type: f.type })),
    ];
    
    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="p-4 border rounded-lg dark:border-slate-700 space-y-4">
                <h3 className="font-semibold text-lg">Conteúdo</h3>
                <div>
                    <label className="block text-sm font-medium">Nome do Formulário (Interno)</label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full rounded-md dark:bg-slate-700" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Título (Público)</label>
                    <input type="text" name="title" value={formData.title} onChange={handleChange} required className="mt-1 block w-full rounded-md dark:bg-slate-700" />
                </div>
                <div>
                    <label className="block text-sm font-medium">Descrição (Público)</label>
                    <textarea name="description" value={formData.description} onChange={handleChange} rows={2} className="mt-1 block w-full rounded-md dark:bg-slate-700"></textarea>
                </div>
                 <div>
                    <label className="block text-sm font-medium">Texto do Botão</label>
                    <input type="text" name="submitButtonText" value={formData.submitButtonText} onChange={handleChange} required className="mt-1 block w-full rounded-md dark:bg-slate-700" />
                </div>
            </div>

            <div className="p-4 border rounded-lg dark:border-slate-700 space-y-4">
                <h3 className="font-semibold text-lg">Campos</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {allPossibleFields.map(field => (
                        <label key={field.id} className="flex items-center space-x-2 p-2 rounded-md bg-slate-100 dark:bg-slate-700 cursor-pointer">
                            <input
                                type="checkbox"
                                checked={formData.fields.some(f => f.mapsToClientField === field.id)}
                                onChange={() => handleFieldToggle(field.id)}
                                className="h-4 w-4 rounded border-slate-300 text-primary-600 focus:ring-primary-500"
                            />
                            <span className="text-sm">{field.name}</span>
                        </label>
                    ))}
                </div>
            </div>

             <div className="p-4 border rounded-lg dark:border-slate-700 space-y-4">
                <h3 className="font-semibold text-lg">Estética</h3>
                 <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <div>
                        <label className="block text-sm font-medium">Cor de Fundo</label>
                        <input type="color" name="backgroundColor" value={formData.backgroundColor} onChange={handleChange} className="mt-1 w-full h-10 rounded-md" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium">Cor do Texto</label>
                        <input type="color" name="textColor" value={formData.textColor} onChange={handleChange} className="mt-1 w-full h-10 rounded-md" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium">Cor do Botão</label>
                        <input type="color" name="buttonColor" value={formData.buttonColor} onChange={handleChange} className="mt-1 w-full h-10 rounded-md" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium">Cor do Texto do Botão</label>
                        <input type="color" name="buttonTextColor" value={formData.buttonTextColor} onChange={handleChange} className="mt-1 w-full h-10 rounded-md" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Tamanho da Fonte</label>
                        <select name="fontSize" value={formData.fontSize} onChange={handleChange} className="mt-1 block w-full rounded-md dark:bg-slate-700">
                            <option value="sm">Pequeno</option>
                            <option value="md">Médio</option>
                            <option value="lg">Grande</option>
                        </select>
                    </div>
                 </div>
            </div>
            
            <div className="p-4 border rounded-lg dark:border-slate-700 space-y-4">
                <h3 className="font-semibold text-lg">Destino do Lead</h3>
                <div>
                    <label className="block text-sm font-medium">Adicionar novo cliente à lista</label>
                    <select name="destinationListId" value={formData.destinationListId} onChange={handleChange} required className="mt-1 block w-full rounded-md dark:bg-slate-700">
                        {lists.map(list => <option key={list.id} value={list.id}>{list.name}</option>)}
                    </select>
                </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
                <button type="button" onClick={onClose} className="px-4 py-2 text-sm bg-white dark:bg-slate-600 border dark:border-slate-500 rounded-md">Cancelar</button>
                <button type="submit" className="px-4 py-2 text-sm text-white bg-primary-600 rounded-md">Salvar Formulário</button>
            </div>
        </form>
    );
};


export const FormManager: React.FC<FormManagerProps> = (props) => {
    const { forms, addForm, updateForm, deleteForm, generateFormSuggestions, isAiAvailable } = props;
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingForm, setEditingForm] = useState<Form | null>(null);
    const [isAiModalOpen, setIsAiModalOpen] = useState(false);
    const [aiObjective, setAiObjective] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [embedCodeModal, setEmbedCodeModal] = useState<Form | null>(null);

    const handleOpenModal = (form: Form | null = null) => {
        setEditingForm(form);
        setIsModalOpen(true);
    };

    const handleSaveForm = (formData: Omit<Form, 'id' | 'createdAt' | 'accountId'> | Form) => {
        if ('id' in formData) {
            updateForm(formData);
        } else {
            addForm(formData);
        }
        setIsModalOpen(false);
        setEditingForm(null);
    };
    
    const handleGenerateWithAi = async () => {
        if (!aiObjective.trim()) return;
        setIsAiLoading(true);
        const suggestions = await generateFormSuggestions(aiObjective);
        if (suggestions) {
            const allPossibleFields = [
                { name: 'Nome', id: 'name', type: 'text' },
                { name: 'Email', id: 'email', type: 'email' },
                ...props.customFields.map(f => ({ name: f.name, id: f.id, type: f.type })),
            ];

            const suggestedFields: FormField[] = suggestions.fieldIds.map((fieldId): FormField | null => {
                const field = allPossibleFields.find(f => f.id === fieldId);
                if (!field) return null;
                return {
                    id: `form-field-${field.id}`,
                    label: field.name,
                    type: field.type as FormFieldType,
                    required: ['name', 'email'].includes(field.id),
                    placeholder: `Seu ${field.name.toLowerCase()}`,
                    mapsToClientField: field.id,
                    options: props.customFields.find(f => f.id === fieldId)?.options,
                };
            }).filter((f): f is FormField => f !== null);

            const newFormPartial: Omit<Form, 'id'|'createdAt'|'accountId'> = {
                name: `Form: ${suggestions.title}`,
                title: suggestions.title,
                description: 'Formulário gerado por IA.',
                fields: suggestedFields,
                destinationListId: props.lists[0]?.id || '',
                submitButtonText: 'Enviar',
                backgroundColor: '#ffffff', textColor: '#0f172a', buttonColor: '#4f46e5', buttonTextColor: '#ffffff', fontSize: 'md',
            };
            setEditingForm(newFormPartial as any); // Open modal with this data
            setIsModalOpen(true);
        } else {
            alert("Não foi possível gerar sugestões para este formulário.");
        }
        setIsAiLoading(false);
        setIsAiModalOpen(false);
        setAiObjective('');
    };

    return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciador de Formulários</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Crie e gerencie formulários para capturar leads de sites externos.</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setIsAiModalOpen(true)} disabled={!isAiAvailable} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-purple-600 rounded-lg shadow-sm hover:bg-purple-700 disabled:bg-slate-400">
                <SparklesIcon className="w-5 h-5"/> Gerar com IA
            </button>
            <button onClick={() => handleOpenModal(null)} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 rounded-lg shadow-sm hover:bg-primary-700">
                <PlusIcon className="w-5 h-5"/> Criar Formulário
            </button>
          </div>
        </div>

        <div className="space-y-3">
            {forms.map(form => (
                <div key={form.id} className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg flex justify-between items-center">
                    <div>
                        <p className="font-semibold text-slate-800 dark:text-slate-200">{form.name}</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{form.title}</p>
                    </div>
                    <div className="flex items-center gap-2">
                         <button onClick={() => setEmbedCodeModal(form)} title="Obter Código" className="text-slate-500 hover:text-primary-600"><DocumentDuplicateIcon className="w-5 h-5"/></button>
                         <button onClick={() => handleOpenModal(form)} title="Editar" className="text-slate-500 hover:text-primary-600"><PencilIcon className="w-5 h-5"/></button>
                         <button onClick={() => deleteForm(form.id)} title="Excluir" className="text-slate-500 hover:text-red-600"><TrashIcon className="w-5 h-5"/></button>
                    </div>
                </div>
            ))}
        </div>

        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingForm ? 'Editar Formulário' : 'Criar Novo Formulário'}>
            <FormBuilder
                initialData={editingForm}
                onSave={handleSaveForm}
                onClose={() => setIsModalOpen(false)}
                {...props}
            />
        </Modal>

        <Modal isOpen={isAiModalOpen} onClose={() => setIsAiModalOpen(false)} title="Gerar Formulário com IA">
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium">Descreva o objetivo do formulário:</label>
                    <input type="text" value={aiObjective} onChange={e => setAiObjective(e.target.value)} placeholder="Ex: Formulário de contato para site de fotografia" className="mt-1 w-full rounded-md dark:bg-slate-700"/>
                </div>
                <div className="flex justify-end">
                    <button onClick={handleGenerateWithAi} disabled={isAiLoading || !aiObjective.trim()} className="px-4 py-2 text-white bg-primary-600 rounded-md disabled:bg-slate-400">
                        {isAiLoading ? 'Gerando...' : 'Gerar Sugestões'}
                    </button>
                </div>
            </div>
        </Modal>

        <Modal isOpen={!!embedCodeModal} onClose={() => setEmbedCodeModal(null)} title="Código de Incorporação">
            <div>
                <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">Copie e cole este código no HTML do seu site onde você deseja que o formulário apareça.</p>
                <textarea
                    readOnly
                    value={`<iframe src="${window.location.origin}?form_id=${embedCodeModal?.id}" title="${embedCodeModal?.name}" style="width: 100%; height: 500px; border: none;"></iframe>`}
                    className="w-full h-32 p-2 font-mono text-sm bg-slate-100 dark:bg-slate-900 rounded-md border-slate-300 dark:border-slate-700"
                ></textarea>
                <div className="flex justify-end mt-4">
                     <button onClick={() => setEmbedCodeModal(null)} className="px-4 py-2 text-sm bg-primary-600 text-white rounded-md">Fechar</button>
                </div>
            </div>
        </Modal>
    </div>
  );
};