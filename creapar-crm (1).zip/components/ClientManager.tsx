import React, { useState, useMemo } from 'react';
import type { Client, List, CustomFieldDefinition, Subscription } from '../types';
import { Modal } from './Modal';
import { PlusIcon, TrashIcon, PencilIcon } from './icons';

interface ClientManagerProps {
  clients: Client[];
  lists: List[];
  customFields: CustomFieldDefinition[];
  subscriptions: Subscription[];
  addClient: (client: Omit<Client, 'id' | 'avatarUrl' | 'createdAt' | 'accountId'>) => void;
  updateClient: (client: Client) => void;
  deleteClient: (clientId: string) => void;
}

const ClientForm: React.FC<{
  lists: List[];
  customFields: CustomFieldDefinition[];
  onSave: (clientData: any) => void;
  onClose: () => void;
  initialData?: Client | null;
}> = ({ lists, customFields, onSave, onClose, initialData }) => {
  const [formData, setFormData] = useState(() => {
    if (initialData) return initialData;
    const defaultCustomFields = customFields.reduce((acc, field) => {
        acc[field.id] = '';
        return acc;
    }, {} as Record<string, any>);
    
    return {
        name: '',
        email: '',
        listId: lists[0]?.id || '',
        customFields: defaultCustomFields
    };
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name in formData) {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleCustomFieldChange = (fieldId: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      customFields: {
        ...prev.customFields,
        [fieldId]: value
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };
  
  const renderFieldInput = (field: CustomFieldDefinition) => {
    const value = formData.customFields[field.id] || '';
    const baseClasses = "mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:placeholder-slate-400 dark:text-white";
    switch (field.type) {
        case 'text':
        case 'number':
        case 'date':
            return <input type={field.type} id={field.id} value={value} onChange={e => handleCustomFieldChange(field.id, e.target.value)} className={baseClasses}/>
        case 'select':
            return (
                <select id={field.id} value={value} onChange={e => handleCustomFieldChange(field.id, e.target.value)} className={baseClasses}>
                    <option value="">Selecione...</option>
                    {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
            );
        default:
            return null;
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Nome Completo</label>
          <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Email</label>
          <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
        </div>
        <div>
           <label htmlFor="listId" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Lista</label>
           <select name="listId" id="listId" value={formData.listId} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
             {lists.map(list => <option key={list.id} value={list.id}>{list.name}</option>)}
           </select>
        </div>
      </div>
      <hr className="dark:border-slate-600"/>
      <h4 className="text-lg font-medium text-slate-800 dark:text-slate-200">Campos Personalizados</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {customFields.map(field => (
          <div key={field.id}>
            <label htmlFor={field.id} className="block text-sm font-medium text-slate-700 dark:text-slate-300">{field.name}</label>
            {renderFieldInput(field)}
          </div>
        ))}
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 focus:outline-none dark:bg-slate-600 dark:text-slate-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancelar</button>
        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Salvar Cliente</button>
      </div>
    </form>
  )
};

export const ClientManager: React.FC<ClientManagerProps> = ({ clients, lists, customFields, subscriptions, addClient, updateClient, deleteClient }) => {
  const [selectedListId, setSelectedListId] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  
  const monthlyClients = useMemo(() => {
    return new Set(subscriptions.filter(s => s.recurrence === 'monthly' && s.status === 'active').map(s => s.clientId));
  }, [subscriptions]);

  const filteredClients = useMemo(() => {
    if (selectedListId === 'all') return clients;
    return clients.filter(c => c.listId === selectedListId);
  }, [clients, selectedListId]);

  const handleOpenModal = (client: Client | null = null) => {
    setEditingClient(client);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingClient(null);
  };

  const handleSaveClient = (clientData: any) => {
    if (editingClient) {
        updateClient({ ...editingClient, ...clientData });
    } else {
        addClient(clientData);
    }
    handleCloseModal();
  };
  
  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
                <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciamento de Clientes</h2>
                <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Veja, adicione e gerencie seus clientes.</p>
            </div>
            <button onClick={() => handleOpenModal()} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-lg shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                <PlusIcon className="w-5 h-5"/>
                Adicionar Cliente
            </button>
        </div>
        
        <div className="mb-4">
            <select value={selectedListId} onChange={e => setSelectedListId(e.target.value)} className="rounded-lg border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
                <option value="all">Todas as Listas</option>
                {lists.map(list => <option key={list.id} value={list.id}>{list.name}</option>)}
            </select>
        </div>

        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                <thead className="bg-slate-50 dark:bg-slate-700/50">
                    <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Nome</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Mensalista</th>
                        {customFields.map(field => (
                            <th key={field.id} scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">{field.name}</th>
                        ))}
                        <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
                    </tr>
                </thead>
                <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
                    {filteredClients.map(client => (
                        <tr key={client.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                            <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                    <div className="flex-shrink-0 h-10 w-10">
                                        <img className="h-10 w-10 rounded-full" src={client.avatarUrl} alt="" />
                                    </div>
                                    <div className="ml-4">
                                        <div className="text-sm font-medium text-slate-900 dark:text-white">{client.name}</div>
                                        <div className="text-sm text-slate-500 dark:text-slate-400">{client.email}</div>
                                    </div>
                                </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                                {monthlyClients.has(client.id) && (
                                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                                        Sim
                                    </span>
                                )}
                            </td>
                            {customFields.map(field => (
                                <td key={field.id} className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">{client.customFields[field.id]?.toString() || 'N/A'}</td>
                            ))}
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                <button onClick={() => handleOpenModal(client)} className="text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300">
                                    <PencilIcon className="w-5 h-5"/>
                                </button>
                                <button onClick={() => deleteClient(client.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                                    <TrashIcon className="w-5 h-5"/>
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingClient ? 'Editar Cliente' : 'Adicionar Novo Cliente'}>
        <ClientForm 
          lists={lists} 
          customFields={customFields} 
          onSave={handleSaveClient} 
          onClose={handleCloseModal} 
          initialData={editingClient} 
        />
      </Modal>
    </div>
  );
};