import React, { useState, useEffect } from 'react';
import { SunIcon, MoonIcon, BellIcon } from './icons';
import type { User, Account } from '../types';

interface TopBarProps {
  title: string;
  currentUser: User;
  accounts: Account[];
  currentAccountId: string;
  setCurrentAccountId: (accountId: string) => void;
}

const UserSwitcher: React.FC<{
  accounts: Account[],
  currentAccountId: string,
  setCurrentAccountId: (accountId: string) => void,
  agencyAccountId: string,
}> = ({ accounts, currentAccountId, setCurrentAccountId, agencyAccountId }) => {
    const clientAccounts = accounts.filter(a => a.type === 'client');
    const currentAccountName = accounts.find(a => a.id === currentAccountId)?.name || 'Selecione uma conta';

    return (
        <div className="relative">
            <select
                value={currentAccountId}
                onChange={(e) => setCurrentAccountId(e.target.value)}
                className="w-full pl-3 pr-10 py-2 text-sm font-semibold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-700/50 rounded-lg border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-500 appearance-none"
            >
                <option value={agencyAccountId}>Visão da Agência</option>
                <optgroup label="Contas de Clientes">
                    {clientAccounts.map(acc => (
                        <option key={acc.id} value={acc.id}>{acc.name}</option>
                    ))}
                </optgroup>
            </select>
        </div>
    );
};

export const TopBar: React.FC<TopBarProps> = ({ title, currentUser, accounts, currentAccountId, setCurrentAccountId }) => {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
        return localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDarkMode);
    localStorage.theme = isDarkMode ? 'dark' : 'light';
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  const displayedUser = accounts.find(a => a.id === currentAccountId);

  return (
    <header className="sticky top-0 z-20 bg-slate-50/50 dark:bg-slate-900/50 backdrop-blur-lg">
      <div className="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-4">
             <h1 className="text-xl font-semibold text-slate-900 dark:text-white">{title}</h1>
             {currentUser.role === 'agency' && (
                <UserSwitcher 
                    accounts={accounts} 
                    currentAccountId={currentAccountId}
                    setCurrentAccountId={setCurrentAccountId}
                    agencyAccountId={currentUser.accountId}
                />
             )}
        </div>
        
        <div className="flex items-center space-x-4">
            <button
                onClick={toggleDarkMode}
                className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                aria-label="Toggle dark mode"
            >
                {isDarkMode ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
            </button>
            <button
                className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                aria-label="Notifications"
            >
                <BellIcon className="w-6 h-6" />
            </button>
            <div className="w-px h-6 bg-slate-200 dark:bg-slate-700"></div>
            <div className="flex items-center space-x-3">
                <img src={currentUser.avatarUrl} alt="User" className="w-9 h-9 rounded-full" />
                <div>
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentUser.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{currentUser.role === 'agency' ? 'Agência' : 'Cliente'}</p>
                </div>
            </div>
        </div>
      </div>
    </header>
  );
};