import React, { useState } from 'react';
import type { WebViewItem } from '../types';
import { GlobeAltIcon } from './icons';

interface WebviewAreaProps {
  webViews: WebViewItem[];
}

export const WebviewArea: React.FC<WebviewAreaProps> = ({ webViews }) => {
  const [activeView, setActiveView] = useState<WebViewItem | null>(webViews[0] || null);

  if (webViews.length === 0) {
      return (
          <div className="flex flex-col items-center justify-center h-full text-center p-4 bg-white dark:bg-slate-800 rounded-xl">
              <GlobeAltIcon className="w-16 h-16 text-slate-400 dark:text-slate-500 mb-4"/>
              <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Nenhuma Webview Configurada</h3>
              <p className="text-slate-500 dark:text-slate-400 mt-2">Vá para Configurações para adicionar URLs à sua área de webview.</p>
          </div>
      )
  }

  return (
    <div className="flex h-full bg-white dark:bg-slate-800 rounded-xl shadow-sm overflow-hidden">
      <aside className="w-64 bg-slate-50 dark:bg-slate-800/50 border-r border-slate-200 dark:border-slate-700 flex flex-col">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">URLs Incorporadas</h2>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
            {webViews.map((view) => (
            <button
                key={view.id}
                onClick={() => setActiveView(view)}
                className={`w-full text-left flex items-center p-2 text-sm rounded-md transition-colors ${
                activeView?.id === view.id
                    ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 font-semibold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
            >
                <GlobeAltIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">{view.title}</span>
            </button>
            ))}
        </nav>
      </aside>
      <main className="flex-1 flex flex-col bg-slate-200 dark:bg-slate-900">
        {activeView ? (
            <iframe
                key={activeView.id}
                src={activeView.url}
                title={activeView.title}
                className="w-full h-full border-0"
                sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation"
            ></iframe>
        ) : (
            <div className="flex items-center justify-center h-full">
                <p className="text-slate-500">Selecione uma URL da barra lateral para visualizá-la.</p>
            </div>
        )}
      </main>
    </div>
  );
};