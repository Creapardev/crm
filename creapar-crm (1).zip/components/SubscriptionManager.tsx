import React, { useState, useMemo } from 'react';
import type { Subscription, Client, Service } from '../types';
import { Modal } from './Modal';
import { PlusIcon, TrashIcon, PencilIcon } from './icons';

interface SubscriptionManagerProps {
  subscriptions: Subscription[];
  clients: Client[];
  services: Service[];
  addSubscription: (subscription: Omit<Subscription, 'id' | 'createdAt' | 'accountId'>) => void;
  updateSubscription: (subscription: Subscription) => void;
  deleteSubscription: (subscriptionId: string) => void;
}

const SubscriptionForm: React.FC<{
  clients: Client[];
  services: Service[];
  onSave: (subscriptionData: Omit<Subscription, 'id' | 'createdAt' | 'accountId'> | Subscription) => void;
  onClose: () => void;
  initialData?: Subscription | null;
}> = ({ clients, services, onSave, onClose, initialData }) => {
  const [formData, setFormData] = useState<Omit<Subscription, 'id' | 'createdAt'| 'accountId'> | Subscription>(() => {
    return initialData || { 
        clientId: '', 
        serviceId: '', 
        startDate: new Date().toISOString().split('T')[0], 
        recurrence: 'monthly', 
        status: 'active' 
    };
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientId || !formData.serviceId) {
        alert("Por favor, selecione um cliente e um serviço.");
        return;
    }
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="clientId" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Cliente</label>
          <select name="clientId" id="clientId" value={formData.clientId} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            <option value="">Selecione um cliente</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="serviceId" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Serviço</label>
          <select name="serviceId" id="serviceId" value={formData.serviceId} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            <option value="">Selecione um serviço</option>
            {services.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="startDate" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Data de Início</label>
          <input type="date" name="startDate" id="startDate" value={formData.startDate} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
        </div>
        <div>
          <label htmlFor="recurrence" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Recorrência</label>
          <select name="recurrence" id="recurrence" value={formData.recurrence} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            <option value="monthly">Mensal</option>
            <option value="yearly">Anual</option>
          </select>
        </div>
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Status</label>
          <select name="status" id="status" value={formData.status} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white">
            <option value="active">Ativa</option>
            <option value="paused">Pausada</option>
            <option value="cancelled">Cancelada</option>
          </select>
        </div>
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 focus:outline-none dark:bg-slate-600 dark:text-slate-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancelar</button>
        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Salvar Assinatura</button>
      </div>
    </form>
  );
};

export const SubscriptionManager: React.FC<SubscriptionManagerProps> = ({ subscriptions, clients, services, addSubscription, updateSubscription, deleteSubscription }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);

  const clientMap = useMemo(() => new Map(clients.map(c => [c.id, c.name])), [clients]);
  const serviceMap = useMemo(() => new Map(services.map(s => [s.id, s])), [services]);

  const handleOpenModal = (subscription: Subscription | null = null) => {
    setEditingSubscription(subscription);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingSubscription(null);
  };

  const handleSaveSubscription = (subscriptionData: Omit<Subscription, 'id' | 'createdAt' | 'accountId'> | Subscription) => {
    if ('id' in subscriptionData) {
      updateSubscription(subscriptionData);
    } else {
      addSubscription(subscriptionData);
    }
    handleCloseModal();
  };
  
  const getStatusChip = (status: Subscription['status']) => {
    const baseClasses = "px-2 inline-flex text-xs leading-5 font-semibold rounded-full";
    switch (status) {
        case 'active': return `${baseClasses} bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200`;
        case 'paused': return `${baseClasses} bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200`;
        case 'cancelled': return `${baseClasses} bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200`;
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciamento de Assinaturas</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Gerencie os serviços recorrentes dos seus clientes.</p>
          </div>
          <button onClick={() => handleOpenModal()} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-lg shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
            <PlusIcon className="w-5 h-5"/>
            Nova Assinatura
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Cliente</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Serviço</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Recorrência</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Data de Início</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {subscriptions.map(sub => {
                const service = serviceMap.get(sub.serviceId);
                return (
                  <tr key={sub.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{clientMap.get(sub.clientId) || 'Cliente não encontrado'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">
                        <div>{service?.name || 'Serviço não encontrado'}</div>
                        <div className="text-xs text-slate-400">{service?.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300"><span className={getStatusChip(sub.status)}>{sub.status}</span></td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">{sub.recurrence === 'monthly' ? 'Mensal' : 'Anual'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">{new Date(sub.startDate).toLocaleDateString('pt-BR', {timeZone: 'UTC'})}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                      <button onClick={() => handleOpenModal(sub)} className="text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300">
                        <PencilIcon className="w-5 h-5"/>
                      </button>
                      <button onClick={() => deleteSubscription(sub.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                        <TrashIcon className="w-5 h-5"/>
                      </button>
                    </td>
                  </tr>
                )}
              )}
            </tbody>
          </table>
        </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingSubscription ? 'Editar Assinatura' : 'Nova Assinatura'}>
        <SubscriptionForm 
          clients={clients}
          services={services}
          onSave={handleSaveSubscription} 
          onClose={handleCloseModal} 
          initialData={editingSubscription} 
        />
      </Modal>
    </div>
  );
};