import React, { useState } from 'react';
import type { Service } from '../types';
import { Modal } from './Modal';
import { PlusIcon, TrashIcon, PencilIcon } from './icons';

interface ServiceManagerProps {
  services: Service[];
  addService: (service: Omit<Service, 'id' | 'accountId'>) => void;
  updateService: (service: Service) => void;
  deleteService: (serviceId: string) => void;
}

const ServiceForm: React.FC<{
  onSave: (serviceData: Omit<Service, 'id' | 'accountId'> | Service) => void;
  onClose: () => void;
  initialData?: Service | null;
}> = ({ onSave, onClose, initialData }) => {
  const [formData, setFormData] = useState(() => {
    return initialData || { name: '', description: '', price: 0 };
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ 
        ...prev, 
        [name]: type === 'number' ? parseFloat(value) || 0 : value 
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Nome do Serviço</label>
        <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
      </div>
      <div>
        <label htmlFor="description" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Descrição</label>
        <textarea name="description" id="description" value={formData.description} onChange={handleChange} rows={3} className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"></textarea>
      </div>
      <div>
        <label htmlFor="price" className="block text-sm font-medium text-slate-700 dark:text-slate-300">Preço (R$)</label>
        <input type="number" name="price" id="price" value={formData.price} onChange={handleChange} required min="0" step="0.01" className="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-primary-500 focus:ring-primary-500 sm:text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-white"/>
      </div>
      <div className="flex justify-end space-x-2 pt-4">
        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md shadow-sm hover:bg-slate-50 focus:outline-none dark:bg-slate-600 dark:text-slate-200 dark:border-slate-500 dark:hover:bg-slate-500">Cancelar</button>
        <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-md shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">Salvar Serviço</button>
      </div>
    </form>
  );
};

export const ServiceManager: React.FC<ServiceManagerProps> = ({ services, addService, updateService, deleteService }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);

  const handleOpenModal = (service: Service | null = null) => {
    setEditingService(service);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingService(null);
  };

  const handleSaveService = (serviceData: Omit<Service, 'id' | 'accountId'> | Service) => {
    if ('id' in serviceData) {
      updateService(serviceData as Service);
    } else {
      addService(serviceData as Omit<Service, 'id' | 'accountId'>);
    }
    handleCloseModal();
  };

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-xl shadow-sm h-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white">Gerenciamento de Serviços</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Adicione, edite e remova os serviços oferecidos.</p>
          </div>
          <button onClick={() => handleOpenModal()} className="px-4 py-2 flex items-center gap-2 text-sm font-medium text-white bg-primary-600 border border-transparent rounded-lg shadow-sm hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
            <PlusIcon className="w-5 h-5"/>
            Adicionar Serviço
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Nome</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Descrição</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Preço</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {services.map(service => (
                <tr key={service.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white">{service.name}</td>
                  <td className="px-6 py-4 whitespace-normal text-sm text-slate-500 dark:text-slate-300 max-w-sm">{service.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-slate-300">
                    {service.price.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                    <button onClick={() => handleOpenModal(service)} className="text-primary-600 hover:text-primary-800 dark:text-primary-400 dark:hover:text-primary-300">
                        <PencilIcon className="w-5 h-5"/>
                    </button>
                    <button onClick={() => deleteService(service.id)} className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
                        <TrashIcon className="w-5 h-5"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingService ? 'Editar Serviço' : 'Adicionar Novo Serviço'}>
        <ServiceForm 
          onSave={handleSaveService} 
          onClose={handleCloseModal} 
          initialData={editingService} 
        />
      </Modal>
    </div>
  );
};