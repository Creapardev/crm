import React, { useState, useMemo } from 'react';
import type { Client, ClientMessage } from '../types';
import { SparklesIcon, InboxIcon } from './icons';

interface ConversationsProps {
  clients: Client[];
  messages: ClientMessage[];
  addClientMessage: (clientId: string, content: string) => void;
  analyzeClientMessage: (messageId: string) => Promise<void>;
  isAiAvailable: boolean;
}

export const Conversations: React.FC<ConversationsProps> = ({
  clients,
  messages,
  addClientMessage,
  analyzeClientMessage,
  isAiAvailable,
}) => {
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [loadingAnalysisId, setLoadingAnalysisId] = useState<string | null>(null);

  const selectedClient = useMemo(() => {
    return clients.find(c => c.id === selectedClientId);
  }, [clients, selectedClientId]);

  const clientMessages = useMemo(() => {
    if (!selectedClientId) return [];
    return messages
      .filter(m => m.clientId === selectedClientId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [messages, selectedClientId]);

  const handleAddMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() && selectedClientId) {
      addClientMessage(selectedClientId, newMessage.trim());
      setNewMessage('');
    }
  };

  const handleAnalyze = async (messageId: string) => {
    setLoadingAnalysisId(messageId);
    try {
        await analyzeClientMessage(messageId);
    } catch(e) {
        console.error("Analysis failed", e);
        alert("Falha ao analisar a mensagem.");
    } finally {
        setLoadingAnalysisId(null);
    }
  };
  
  const renderAnalysis = (analysis: ClientMessage['analysis']) => {
    if (!analysis) return null;

    const sentimentColors = {
        positive: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
        negative: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300',
        neutral: 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300',
    }

    return (
        <div className="mt-2 p-3 border-l-4 border-primary-500 bg-slate-50 dark:bg-slate-700/50 rounded-r-lg space-y-2">
            <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${sentimentColors[analysis.sentiment]}`}>
                    {analysis.sentiment.charAt(0).toUpperCase() + analysis.sentiment.slice(1)}
                </span>
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{analysis.intent}</span>
            </div>
            <div>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">Ações Sugeridas:</p>
                <ul className="list-disc list-inside text-sm text-slate-500 dark:text-slate-400 space-y-1">
                    {analysis.suggestedActions.map((action, i) => <li key={i}>{action}</li>)}
                </ul>
            </div>
        </div>
    )
  }

  return (
    <div className="flex h-full bg-white dark:bg-slate-800 rounded-xl shadow-sm overflow-hidden">
      <aside className="w-1/3 xl:w-1/4 bg-slate-50 dark:bg-slate-800/50 border-r border-slate-200 dark:border-slate-700 flex flex-col">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Clientes</h2>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {clients.map(client => (
            <button
              key={client.id}
              onClick={() => setSelectedClientId(client.id)}
              className={`w-full text-left flex items-center p-2 text-sm rounded-md transition-colors ${
                selectedClientId === client.id
                  ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 font-semibold'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <img src={client.avatarUrl} alt={client.name} className="w-6 h-6 rounded-full mr-2 flex-shrink-0" />
              <span className="truncate">{client.name}</span>
            </button>
          ))}
        </nav>
      </aside>
      <main className="flex-1 flex flex-col">
        {!selectedClient ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <InboxIcon className="w-16 h-16 text-slate-400 dark:text-slate-500 mb-4" />
            <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Selecione uma Conversa</h3>
            <p className="text-slate-500 dark:text-slate-400 mt-2">Escolha um cliente na barra lateral para ver e analisar as mensagens.</p>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center gap-3">
                 <img src={selectedClient.avatarUrl} alt={selectedClient.name} className="w-10 h-10 rounded-full"/>
                 <h2 className="text-lg font-semibold text-slate-900 dark:text-white">{selectedClient.name}</h2>
            </div>
            <div className="flex-1 p-4 space-y-4 overflow-y-auto bg-slate-100/50 dark:bg-slate-900/50">
                {clientMessages.map(message => (
                    <div key={message.id} className="flex flex-col items-start">
                        <div className="max-w-xl bg-white dark:bg-slate-700 rounded-lg p-3 shadow-sm">
                           <p className="text-sm text-slate-800 dark:text-slate-200">{message.content}</p>
                           <span className="text-xs text-slate-400 mt-1 block text-right">
                               {new Date(message.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                           </span>
                        </div>
                        {isAiAvailable && (
                             <button onClick={() => handleAnalyze(message.id)} disabled={loadingAnalysisId === message.id} className="flex items-center gap-1 mt-1 text-xs text-primary-600 dark:text-primary-400 hover:underline disabled:cursor-wait disabled:text-slate-400">
                                <SparklesIcon className={`w-4 h-4 ${loadingAnalysisId === message.id ? 'animate-pulse' : ''}`}/>
                                {loadingAnalysisId === message.id ? 'Analisando...' : 'Analisar com IA'}
                            </button>
                        )}
                        {message.analysis && renderAnalysis(message.analysis)}
                    </div>
                ))}
            </div>
            <div className="p-4 border-t border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                <form onSubmit={handleAddMessage} className="flex gap-2">
                    <textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder={`Cole a mensagem recebida de ${selectedClient.name}...`}
                        rows={2}
                        className="flex-1 block w-full rounded-md border-slate-300 shadow-sm sm:text-sm dark:bg-slate-700 dark:border-slate-600"
                    />
                    <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-md hover:bg-primary-700 disabled:bg-slate-400" disabled={!newMessage.trim()}>
                        Adicionar
                    </button>
                </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
