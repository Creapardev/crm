import React from 'react';
import type { CalendarEvent } from '../types';
import { Calendar, momentLocalizer, Views } from 'react-big-calendar';
import moment from 'moment';
import 'moment/locale/pt-br';

moment.locale('pt-br');
const localizer = momentLocalizer(moment);

const messages = {
  allDay: 'Dia todo',
  previous: 'Anterior',
  next: 'Próximo',
  today: 'Hoje',
  month: 'Mês',
  week: 'Semana',
  day: 'Dia',
  agenda: 'Agenda',
  date: 'Data',
  time: 'Hora',
  event: 'Evento',
  showMore: (total: number) => `+ Ver mais (${total})`,
};

export const CalendarView: React.FC<{
  events: CalendarEvent[];
  isLoading: boolean;
  error: string | null;
  calendarUrl: string;
}> = ({ events, isLoading, error, calendarUrl }) => {

  const calendarStyles = `
    .rbc-calendar { background-color: var(--rbc-background-color); border: 1px solid var(--rbc-border-color); color: var(--rbc-text-color); height: 100%; border-radius: 0.75rem; overflow: hidden; }
    .rbc-toolbar { border-bottom: 1px solid var(--rbc-border-color); padding: 0.75rem 1rem; }
    .rbc-toolbar button { color: var(--rbc-button-text-color); background-color: transparent; border: 1px solid var(--rbc-button-border-color); padding: 0.375rem 0.75rem; border-radius: 0.5rem; transition: background-color 0.2s; }
    .rbc-toolbar button:hover { background-color: var(--rbc-off-range-bg-color); }
    .rbc-toolbar button:active, .rbc-toolbar button.rbc-active { background-color: var(--rbc-active-bg-color); border-color: var(--rbc-active-border-color); color: var(--rbc-active-text-color); }
    .rbc-off-range-bg { background: var(--rbc-off-range-bg-color); }
    .rbc-header { border-bottom: 1px solid var(--rbc-header-border-color); color: var(--rbc-header-text-color); padding: 0.5rem 0; }
    .rbc-day-bg, .rbc-month-row, .rbc-time-gutter, .rbc-time-header-gutter, .rbc-time-content > * > * > .rbc-time-slot, .rbc-timeslot-group { border-color: var(--rbc-day-border-color); }
    .rbc-event { background-color: var(--rbc-event-bg-color); color: var(--rbc-event-text-color); border: none; border-radius: 0.375rem; padding: 2px 5px; }
    .rbc-event.rbc-selected { background-color: var(--rbc-event-selected-bg-color); }
    .rbc-today { background-color: var(--rbc-today-bg-color); }
    html.dark {
        --rbc-text-color: #e5e7eb; --rbc-button-text-color: #d1d5db; --rbc-button-border-color: #4b5563;
        --rbc-active-bg-color: #4f46e5; --rbc-active-border-color: #4338ca; --rbc-active-text-color: #ffffff;
        --rbc-off-range-bg-color: #1f2937; --rbc-header-border-color: #374151; --rbc-header-text-color: #f3f4f6;
        --rbc-day-border-color: #374151; --rbc-event-bg-color: #4338ca; --rbc-event-text-color: #ffffff;
        --rbc-event-selected-bg-color: #312e81; --rbc-today-bg-color: #1e293b; --rbc-background-color: #0f172a;
        --rbc-border-color: #374151;
    }
    html:not(.dark) {
        --rbc-text-color: #334155; --rbc-button-text-color: #475569; --rbc-button-border-color: #cbd5e1;
        --rbc-active-bg-color: #4f46e5; --rbc-active-border-color: #4338ca; --rbc-active-text-color: #ffffff;
        --rbc-off-range-bg-color: #f1f5f9; --rbc-header-border-color: #e2e8f0; --rbc-header-text-color: #1e293b;
        --rbc-day-border-color: #e2e8f0; --rbc-event-bg-color: #6366f1; --rbc-event-text-color: #ffffff;
        --rbc-event-selected-bg-color: #4338ca; --rbc-today-bg-color: #eef2ff; --rbc-background-color: #ffffff;
        --rbc-border-color: #e2e8f0;
    }
  `;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full bg-white dark:bg-slate-800 rounded-xl">
        <p className="text-lg text-slate-500 dark:text-slate-400 animate-pulse">Carregando eventos...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-red-50 dark:bg-red-900/10 rounded-xl">
        <h3 className="text-xl font-semibold text-red-600 dark:text-red-400">Erro no Calendário</h3>
        <p className="text-slate-600 dark:text-slate-300 mt-2">{error}</p>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-4">
            Verifique a URL iCal em <b className="font-semibold">Configurações</b>.
        </p>
      </div>
    );
  }
  
  return (
    <div className="h-full">
        <style>{calendarStyles}</style>
         {events.length === 0 && !calendarUrl ? (
            <div className="flex flex-col items-center justify-center h-full text-center bg-white dark:bg-slate-800 rounded-xl">
                <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Nenhum Calendário Configurado</h3>
                <p className="text-slate-500 dark:text-slate-400 mt-2">
                    Vá para <b className="font-semibold">Configurações</b> para adicionar a URL do seu calendário.
                </p>
            </div>
        ) : (
            <Calendar
                localizer={localizer}
                events={events}
                startAccessor="start"
                endAccessor="end"
                views={[Views.MONTH, Views.WEEK, Views.DAY, Views.AGENDA]}
                messages={messages}
            />
        )}
    </div>
  );
};