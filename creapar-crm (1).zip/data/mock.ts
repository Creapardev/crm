import type { List, CustomFieldDefinition, Client, WebViewItem, Service, Subscription, Automation, OneOffJob, Task, SWOTAnalysis, ClientQuestionnaire, BCGMatrixAnalysis, GmbProfile, Account, User, PersonaAnalysis, ClientMessage, ScheduledJob, Form } from '../types';

const d = (daysAgo: number) => {
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    return date.toISOString();
}

// --- MULTI-TENANT MOCK DATA ---
export const initialAccounts: Account[] = [
    { id: 'acc-agency', name: 'Creapar Agência', type: 'agency', geminiApiKey: '', whatsappApiUrl: '', whatsappApiKey: '', whatsappInstanceId: '' },
    { id: 'acc-client-1', name: 'Tech Solutions Inc.', type: 'client', geminiApiKey: '', whatsappApiUrl: '', whatsappApiKey: '', whatsappInstanceId: '' },
    { id: 'acc-client-2', name: 'Gourmet Foods Co.', type: 'client', geminiApiKey: '', whatsappApiUrl: '', whatsappApiKey: '', whatsappInstanceId: '' },
];

export const initialUsers: User[] = [
    { id: 'user-agency', name: 'Admin Agência', email: 'admin@creapar.com', password: 'password', isActive: true, avatarUrl: 'https://i.pravatar.cc/100?u=admin-agency', accountId: 'acc-agency', role: 'agency' },
    { id: 'user-client-1', name: 'John Smith', email: 'john@techsolutions.com', password: 'password', isActive: true, avatarUrl: 'https://i.pravatar.cc/100?u=john-smith', accountId: 'acc-client-1', role: 'client' },
    { id: 'user-client-2', name: 'Maria Garcia', email: 'maria@gourmetfoods.com', password: 'password', isActive: true, avatarUrl: 'https://i.pravatar.cc/100?u=maria-garcia', accountId: 'acc-client-2', role: 'client' },
];

// Data now includes `accountId` for isolation
export const initialLists: List[] = [
  // Agency Lists (if they use it for their own leads)
  { id: 'list-agency-1', accountId: 'acc-agency', name: 'Agency Leads' },

  // Tech Solutions Lists
  { id: 'list-1', accountId: 'acc-client-1', name: 'New Leads' },
  { id: 'list-2', accountId: 'acc-client-1', name: 'Contacted' },
  { id: 'list-3', accountId: 'acc-client-1', name: 'Proposal Sent' },
  { id: 'list-4', accountId: 'acc-client-1', name: 'Customer' },
  { id: 'list-cold', accountId: 'acc-client-1', name: 'Cold Leads' },

  // Gourmet Foods Lists
  { id: 'list-5', accountId: 'acc-client-2', name: 'Leads (Restaurantes)' },
  { id: 'list-6', accountId: 'acc-client-2', name: 'Degustação Agendada' },
  { id: 'list-7', accountId: 'acc-client-2', name: 'Cliente Ativo' },
];

export const initialCustomFields: CustomFieldDefinition[] = [
  { id: 'field-1', accountId: 'acc-client-1', name: 'Lead Source', type: 'select', options: ['Website', 'Referral', 'Cold Call', 'Event'] },
  { id: 'field-2', accountId: 'acc-client-1', name: 'Company Size', type: 'number' },
  { id: 'field-phone', accountId: 'acc-client-1', name: 'WhatsApp', type: 'text' },
  { id: 'field-last-contact', accountId: 'acc-client-1', name: 'Last Contact Date', type: 'date' },
  { id: 'field-3', accountId: 'acc-client-2', name: 'Tipo de Culinária', type: 'text' },
];

export const initialClients: Client[] = [
  // Tech Solutions Clients
  { id: 'client-1', accountId: 'acc-client-1', name: 'Innovate Corp', email: 'contact@innovate.com', avatarUrl: 'https://i.pravatar.cc/100?u=innovate', listId: 'list-1', customFields: { 'field-1': 'Website', 'field-2': 50, 'field-phone': '5511999998888', 'field-last-contact': d(10) }, createdAt: d(1) },
  { id: 'client-2', accountId: 'acc-client-1', name: 'Data Systems', email: 'info@datasys.com', avatarUrl: 'https://i.pravatar.cc/100?u=datasys', listId: 'list-4', customFields: { 'field-1': 'Referral', 'field-2': 200, 'field-phone': '5521988887777', 'field-last-contact': d(5) }, createdAt: d(5) },
  { id: 'client-cold', accountId: 'acc-client-1', name: 'Legacy Solutions', email: 'contact@legacy.com', avatarUrl: 'https://i.pravatar.cc/100?u=legacy', listId: 'list-cold', customFields: { 'field-1': 'Cold Call', 'field-2': 10, 'field-phone': '5531977776666', 'field-last-contact': d(100) }, createdAt: d(120) },

  // Gourmet Foods Clients
  { id: 'client-3', accountId: 'acc-client-2', name: 'Pasta Palace', email: 'manager@pastapalace.com', avatarUrl: 'https://i.pravatar.cc/100?u=pasta', listId: 'list-5', customFields: { 'field-3': 'Italiana' }, createdAt: d(3) },
  { id: 'client-4', accountId: 'acc-client-2', name: 'Sushi Central', email: 'contact@sushicentral.com', avatarUrl: 'https://i.pravatar.cc/100?u=sushi', listId: 'list-7', customFields: { 'field-3': 'Japonesa' }, createdAt: d(10) },
];

export const initialWebViews: WebViewItem[] = [
    { id: 'wv-1', accountId: 'acc-agency', title: 'Creapar Website', url: 'https://creapar.com' },
];

export const initialServices: Service[] = [
    { id: 'service-1', accountId: 'acc-client-1', name: 'Cloud Hosting', description: 'Plano mensal de cloud hosting.', price: 250.00 },
    { id: 'service-2', accountId: 'acc-client-2', name: 'Fornecimento de Queijos', description: 'Fornecimento mensal de queijos artesanais.', price: 800.00 },
];

export const initialSubscriptions: Subscription[] = [
    { id: 'sub-1', accountId: 'acc-client-1', clientId: 'client-2', serviceId: 'service-1', startDate: '2023-01-15', recurrence: 'monthly', status: 'active', createdAt: d(10) },
    { id: 'sub-2', accountId: 'acc-client-2', clientId: 'client-4', serviceId: 'service-2', startDate: '2023-05-20', recurrence: 'monthly', status: 'active', createdAt: d(12) },
];

export const initialOneOffJobs: OneOffJob[] = [
    { id: 'job-1', accountId: 'acc-client-1', clientId: 'client-1', title: 'Server Migration', description: 'Migrate legacy server.', value: 1500, dueDate: '2023-11-10', status: 'Pendente', createdAt: d(0) },
    { id: 'job-2', accountId: 'acc-client-2', clientId: 'client-3', title: 'Consultoria de Menu', description: 'Consultoria para novo menu de inverno.', value: 950, dueDate: '2023-10-25', status: 'Pago', createdAt: d(8) },
];

export const initialTasks: Task[] = [
    { id: 'task-1', accountId: 'acc-client-1', title: 'Follow up com Innovate Corp', clientId: 'client-1', dueDate: d(-3), isCompleted: false, createdAt: d(4) },
    { id: 'task-2', accountId: 'acc-client-2', title: 'Enviar amostras para Pasta Palace', clientId: 'client-3', dueDate: d(-1), isCompleted: true, createdAt: d(3) },
];

export const initialAutomations: Automation[] = [
    {
        id: 'auto-2',
        accountId: 'acc-client-1',
        name: 'Drip Campaign para Propostas',
        triggerType: 'client_moved_to_list',
        triggerFilters: { listId: 'list-3' },
        conditions: [],
        actions: [
            { type: 'create_task', titleTemplate: 'Fazer follow-up da proposta com {{client.name}}', dueDays: 3 },
            { type: 'delay', days: 3 },
            { type: 'send_whatsapp', phoneFieldId: 'field-phone', messageTemplate: 'Olá {{client.name}}, passando para saber se teve alguma dúvida sobre a proposta. Abraços!' },
        ],
        enabled: true
    },
    {
        id: 'auto-reengage',
        accountId: 'acc-client-1',
        name: 'Reengajamento Semanal de Leads Frios',
        triggerType: 'scheduled_weekly_check',
        triggerFilters: {},
        conditions: [
            { fieldId: 'field-last-contact', operator: 'is_less_than', value: d(90) } // Placeholder value, logic handles actual date
        ],
        actions: [
            { type: 'send_whatsapp', phoneFieldId: 'field-phone', messageTemplate: 'Olá {{client.name}}, tudo bem? Faz um tempo que não conversamos. Vi que tinha interesse em nossos serviços e queria saber se ainda faz sentido para você. Abraços!'}
        ],
        enabled: true
    }
];

export const initialSwotAnalyses: SWOTAnalysis[] = [
    { id: 'swot-1', accountId: 'acc-client-1', clientId: 'client-1', strengths: 'Marca bem reconhecida no mercado.', weaknesses: 'Processo de vendas antigo e pouco eficiente.', opportunities: 'Expansão para mercados internacionais.', threats: 'Novos concorrentes com preços agressivos.' }
];

export const initialClientQuestionnaires: ClientQuestionnaire[] = [];
export const initialBcgAnalyses: BCGMatrixAnalysis[] = [];
export const initialGmbProfiles: GmbProfile[] = [];
export const initialPersonas: PersonaAnalysis[] = [];
export const initialClientMessages: ClientMessage[] = [];
export const initialScheduledJobs: ScheduledJob[] = [];

export const initialForms: Form[] = [
  {
    id: 'form-1',
    accountId: 'acc-client-1',
    name: 'Formulário de Contato Site',
    title: 'Entre em contato conosco',
    description: 'Preencha o formulário abaixo e nossa equipe retornará em breve.',
    fields: [
      { id: 'form-field-1', label: 'Seu Nome', type: 'text', required: true, placeholder: 'João Silva', mapsToClientField: 'name' },
      { id: 'form-field-2', label: 'Seu Melhor Email', type: 'email', required: true, placeholder: 'joao.silva@example.com', mapsToClientField: 'email' },
      { id: 'form-field-3', label: 'De onde você nos conheceu?', type: 'select', required: false, options: ['Website', 'Referral', 'Cold Call', 'Event'], mapsToClientField: 'field-1' },
    ],
    destinationListId: 'list-1', // New Leads for Tech Solutions
    submitButtonText: 'Enviar Mensagem',
    createdAt: d(2),
    backgroundColor: '#ffffff',
    textColor: '#0f172a',
    buttonColor: '#4f46e5',
    buttonTextColor: '#ffffff',
    fontSize: 'md',
  }
];